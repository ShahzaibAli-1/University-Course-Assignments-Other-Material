// client.c
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>

int main() {
    char input[256];
    int sock;
    struct sockaddr_in server_address;

    // Create the socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup the address
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(3001);

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_address, sizeof(server_address)) == -1) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }
    printf("Connection successful!\n");


    printf("Enter first number: ");
    fgets(input, sizeof(input), stdin);
    send(sock, input, strlen(input), 0);

    printf("Enter operator +, -, *, /: ");
    fgets(input, sizeof(input), stdin);
    send(sock, input, strlen(input), 0);

    printf("Enter second number: ");
    fgets(input, sizeof(input), stdin);
    send(sock, input, strlen(input), 0);

    close(sock);
    return 0;
}
