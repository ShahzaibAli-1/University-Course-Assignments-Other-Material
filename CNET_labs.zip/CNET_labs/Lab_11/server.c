#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netinet/in.h>
#include <string.h>

#include <unistd.h>

int main() {
    char buf[256];
    int server_socket, client_socket;
    struct sockaddr_in server_address;

    // Create the server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup the address
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(3001);
    server_address.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket
    if (bind(server_socket, (struct sockaddr *)&server_address, sizeof(server_address)) == -1) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, 5) == -1) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Accept a client
    client_socket = accept(server_socket, NULL, NULL);
    if (client_socket == -1) {
        perror("Accept failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
    printf("Connection successful!\n");


    // number1
    memset(buf, 0, sizeof(buf));
    recv(client_socket, buf, sizeof(buf), 0);
    int num1 = atoi(buf);

    //operator
    memset(buf, 0, sizeof(buf));
    recv(client_socket, buf, sizeof(buf), 0);
    char operator = buf[0];

    //receive second number
    memset(buf, 0, sizeof(buf));
    recv(client_socket, buf, sizeof(buf), 0);
    int num2 = atoi(buf);

    //perform calculation
    int result;
    switch(operator) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 != 0)
                result = num1 / num2;
            else {
                printf("Error: Division by zero\n");
                close(client_socket);
                close(server_socket);
                return 1;
            }
            break;
        default:
            printf("Invalid operator received.\n");
            close(client_socket);
            close(server_socket);
            return 1;
    }

    // Display the result
    printf("Result: %d\n", result);

    // Close sockets
    close(client_socket);
    close(server_socket);

    return 0;
}
