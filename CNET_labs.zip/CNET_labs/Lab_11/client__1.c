#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main() {
    int connection_fd;
    struct sockaddr_in remote_addr;
    char message[256];

    // Create socket
    connection_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (connection_fd < 0) {
        perror("Unable to create socket");
        exit(EXIT_FAILURE);
    }

    // Setup destination info
    remote_addr.sin_family = AF_INET;
    remote_addr.sin_port = htons(3002);
    remote_addr.sin_addr.s_addr = INADDR_ANY;

    // Establish connection
    if (connect(connection_fd, (struct sockaddr *)&remote_addr, sizeof(remote_addr)) < 0) {
        perror("Unable to connect");
        close(connection_fd);
        exit(EXIT_FAILURE);
    }
    printf("Successfully connected to server.\n");

    // Receive initial message from server
    bzero(message, sizeof(message));
    recv(connection_fd, message, sizeof(message), 0);
    printf("Greeting from server: %s\n", message);

    // Communication loop
    for (int attempt = 0; attempt < 5; attempt++) {
        printf("\nType a string: ");
        bzero(message, sizeof(message));
        fgets(message, sizeof(message), stdin);

        // Strip newline
        size_t len = strcspn(message, "\n");
        message[len] = '\0';

        send(connection_fd, message, strlen(message), 0);

        bzero(message, sizeof(message));
        recv(connection_fd, message, sizeof(message), 0);
        printf("Server reversed: %s\n", message);
    }

    // End connection
    close(connection_fd);
    return 0;
}
