#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

// Function to invert a string in place
void flip_text(char *text) {
    int len = strlen(text);
    for (int j = 0; j < len / 2; j++) {
        char swap = text[j];
        text[j] = text[len - j - 1];
        text[len - j - 1] = swap;
    }
}

int main() {
    int listener_fd, conn_fd;
    struct sockaddr_in local_addr;
    char data_buf[256];

    // Set up a TCP socket
    listener_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listener_fd < 0) {
        perror("Unable to create socket");
        exit(EXIT_FAILURE);
    }

    // Configure the socket address
    local_addr.sin_family = AF_INET;
    local_addr.sin_port = htons(3002);
    local_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind the socket to the specified address and port
    if (bind(listener_fd, (struct sockaddr *)&local_addr, sizeof(local_addr)) < 0) {
        perror("Binding failed");
        close(listener_fd);
        exit(EXIT_FAILURE);
    }

    // Set socket to listen mode
    listen(listener_fd, 5);

    // Wait for a connection
    conn_fd = accept(listener_fd, NULL, NULL);
    if (conn_fd < 0) {
        perror("Connection failed");
        close(listener_fd);
        exit(EXIT_FAILURE);
    }

    printf("A client has connected.\n");

    // Send a greeting
    char greet[] = "connected to server";
    send(conn_fd, greet, sizeof(greet), 0);

    // Handle client messages
    for (int round = 0; round < 5; round++) {
        memset(data_buf, 0, sizeof(data_buf));
        recv(conn_fd, data_buf, sizeof(data_buf), 0);
        printf("Message received: %s\n", data_buf);

        flip_text(data_buf);
        send(conn_fd, data_buf, strlen(data_buf), 0);
    }

    close(conn_fd);
    close(listener_fd);

    return 0;
}
