#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <fcntl.h>

#define PORT 3001
#define MAX_CLIENTS 3
#define BUFFER_SIZE 1024

int client_sockets[MAX_CLIENTS];
int pipe_fds[MAX_CLIENTS][2];

void broadcast_message(const char* message, int sender_index) {
    for (int i = 0; i < MAX_CLIENTS; ++i) {
        if (client_sockets[i] != -1 && i != sender_index) {
            write(client_sockets[i], message, strlen(message));
        }
    }
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    fd_set read_fds;

    // Initialize client sockets
    for (int i = 0; i < MAX_CLIENTS; i++) client_sockets[i] = -1;

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(1);
    }

    if (listen(server_socket, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        exit(1);
    }

    printf("Broadcast server running on port %d...\n", PORT);

    int connected_clients = 0;

    // Accept up to MAX_CLIENTS clients
    while (connected_clients < MAX_CLIENTS) {
        client_socket = accept(server_socket, (struct sockaddr*)&client_addr, &client_len);
        if (client_socket < 0) {
            perror("Accept failed");
            continue;
        }

        client_sockets[connected_clients] = client_socket;

        // Create a pipe for communication from child to parent
        if (pipe(pipe_fds[connected_clients]) < 0) {
            perror("Pipe failed");
            exit(1);
        }

        pid_t pid = fork();

        if (pid == 0) {  // Child process
            close(server_socket);
            close(pipe_fds[connected_clients][0]); // Close read end in child
            char buffer[BUFFER_SIZE];

            while (1) {
                memset(buffer, 0, BUFFER_SIZE);
                int bytes = read(client_socket, buffer, sizeof(buffer));
                if (bytes <= 0) {
                    printf("Client %d disconnected.\n", connected_clients + 1);
                    close(client_socket);
                    exit(0);
                }

                write(pipe_fds[connected_clients][1], buffer, strlen(buffer));
            }
        } else { // Parent process
            close(pipe_fds[connected_clients][1]); // Close write end in parent
            connected_clients++;
        }
    }

    // Broadcast loop
    char buffer[BUFFER_SIZE];
    while (1) {
        FD_ZERO(&read_fds);
        int max_fd = -1;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (client_sockets[i] != -1) {
                FD_SET(pipe_fds[i][0], &read_fds);
                if (pipe_fds[i][0] > max_fd)
                    max_fd = pipe_fds[i][0];
            }
        }

        int activity = select(max_fd + 1, &read_fds, NULL, NULL, NULL);
        if (activity < 0) {
            perror("select error");
            break;
        }

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (FD_ISSET(pipe_fds[i][0], &read_fds)) {
                memset(buffer, 0, BUFFER_SIZE);
                int bytes = read(pipe_fds[i][0], buffer, sizeof(buffer));
                if (bytes > 0) {
                    printf("From client %d: %s", i + 1, buffer);
                    broadcast_message(buffer, i);
                }
            }
        }
    }

    close(server_socket);
    return 0;
}
