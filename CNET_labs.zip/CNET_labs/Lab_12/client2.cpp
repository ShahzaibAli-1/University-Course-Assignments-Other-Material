#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 3001
#define MAX_LEN 1024
#define SERVER_IP "127.0.0.1"

void encrypt(char *msg) {
    for (int i = 0; msg[i]; i++) {
        msg[i] += 3;
    }
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[MAX_LEN];
    socklen_t len = sizeof(server_addr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    while (1) {
        printf("[Client] Enter message: ");
        fgets(buffer, MAX_LEN, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        encrypt(buffer);
        sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&server_addr, len);

        if (strcmp(buffer, "h{lw") == 0) break;

        memset(buffer, 0, MAX_LEN);
        int recv_len = recvfrom(sockfd, buffer, MAX_LEN, 0, (struct sockaddr *)&server_addr, &len);
        if (recv_len < 0) {
            perror("Receive failed");
            break;
        }

        printf("[Server Encrypted]: %s (Size: %d bytes)\n", buffer, recv_len);

        if (strcmp(buffer, "h{lw") == 0) {
            printf("Exit signal received. Client shutting down.\n");
            break;
        }
    }

    close(sockfd);
    return 0;
}
