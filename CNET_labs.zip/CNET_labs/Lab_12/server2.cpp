#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 3001
#define MAX_LEN 1024

void encrypt(char *msg) {
    for (int i = 0; msg[i]; i++) {
        msg[i] += 3;
    }
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[MAX_LEN];
    socklen_t len = sizeof(client_addr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(1);
    }

    printf("Server started. Waiting for messages...\n");

    while (1) {
        memset(buffer, 0, MAX_LEN);
        int recv_len = recvfrom(sockfd, buffer, MAX_LEN, 0, (struct sockaddr *)&client_addr, &len);
        if (recv_len < 0) {
            perror("Receive failed");
            break;
        }

        printf("[Client Encrypted]: %s (Size: %d bytes)\n", buffer, recv_len);

        if (strcmp(buffer, "h{lw") == 0) {  // "exit" encrypted with +3
            printf("Exit signal received. Server shutting down.\n");
            break;
        }

        // Send reply
        printf("[Server] Enter message: ");
        fgets(buffer, MAX_LEN, stdin);
        buffer[strcspn(buffer, "\n")] = '\0';

        encrypt(buffer);
        sendto(sockfd, buffer, strlen(buffer), 0, (struct sockaddr *)&client_addr, len);

        if (strcmp(buffer, "h{lw") == 0) break;
    }

    close(sockfd);
    return 0;
}
