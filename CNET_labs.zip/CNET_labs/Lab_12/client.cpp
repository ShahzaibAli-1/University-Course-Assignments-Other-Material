#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define SERVER_IP "127.0.0.1"
#define PORT 3001

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[256];
    socklen_t addr_len = sizeof(server_addr);

    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr(SERVER_IP);

    // Initial message to trigger server
    const char *hello = "Hello, server!";
    sendto(sock, hello, strlen(hello) + 1, 0, (struct sockaddr *)&server_addr, addr_len);

    // Receive question
    recvfrom(sock, buffer, sizeof(buffer), 0, (struct sockaddr *)&server_addr, &addr_len);
    printf("Received question: %s\n", buffer);

    // Send answer
    printf("Your answer: ");
    fgets(buffer, sizeof(buffer), stdin);
    buffer[strcspn(buffer, "\n")] = '\0';  // Remove newline
    sendto(sock, buffer, strlen(buffer) + 1, 0, (struct sockaddr *)&server_addr, addr_len);

    // Receive result
    recvfrom(sock, buffer, sizeof(buffer), 0, (struct sockaddr *)&server_addr, &addr_len);
    printf("Server says: %s\n", buffer);

    close(sock);
    return 0;
}
