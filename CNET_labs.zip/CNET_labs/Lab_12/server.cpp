#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 3001

int main() {
    int server_socket;
    struct sockaddr_in server_addr, client_addr;
    char buffer[256];
    socklen_t addr_len = sizeof(client_addr);

    const char *question = "What is 2 + 2?";
    const char *correct_answer = "4";

    server_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        exit(1);
    }

    printf("Server running on port %d...\n", PORT);

    // Wait for initial contact
    recvfrom(server_socket, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &addr_len);
    printf("Client connected. Sending question...\n");

    // Send question
    sendto(server_socket, question, strlen(question) + 1, 0, (struct sockaddr *)&client_addr, addr_len);

    // Receive answer
    memset(buffer, 0, sizeof(buffer));
    recvfrom(server_socket, buffer, sizeof(buffer), 0, (struct sockaddr *)&client_addr, &addr_len);
    printf("Received answer: %s\n", buffer);

    // Prepare response
    const char *response = (strcmp(buffer, correct_answer) == 0) ? "Correct!" : "Wrong! The correct answer is 4.";
    sendto(server_socket, response, strlen(response) + 1, 0, (struct sockaddr *)&client_addr, addr_len);

    close(server_socket);
    return 0;
}
