#include<iostream>
#include<pthread.h>
#include<unistd.h>

using namespace std;

pthread_mutex_t bridge_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t bridge_available = PTHREAD_COND_INITIALIZER;

int cars, boats, car_time, boat_time;
bool car_on_bridge = false, boat_on_bridge = false;

void* car_pass(void* arg) {
    int car_id = *((int*)arg);
    pthread_mutex_lock(&bridge_lock);
    while (boat_on_bridge) {
        pthread_cond_wait(&bridge_available, &bridge_lock);
    }
    car_on_bridge = true;

    cout << "Car " << car_id << " passing\n";
    for (int i = 0; i < car_time; i++) {
        cout << "* ";

        sleep(1);
    }
    cout << "\n";

    car_on_bridge = false;
    pthread_cond_broadcast(&bridge_available);
    pthread_mutex_unlock(&bridge_lock);
    pthread_exit(NULL);
}

void* boat_pass(void* arg) {
    int boat_id = *((int*)arg);
    pthread_mutex_lock(&bridge_lock);
    while (car_on_bridge) {
        pthread_cond_wait(&bridge_available, &bridge_lock);
    }
    boat_on_bridge = true;

    cout << "Boat " << boat_id << " passing\n";
    for (int i = 0; i < boat_time; i++) {
        cout << "* ";

        sleep(1);
    }
    cout << "\n";

    boat_on_bridge = false;
    pthread_cond_broadcast(&bridge_available);
    pthread_mutex_unlock(&bridge_lock);
    pthread_exit(NULL);
}

int main() {
    cout << "Enter number of cars, boats, time for car, and time for boat: ";
    cin >> cars >> boats >> car_time >> boat_time;

    pthread_t car_threads[cars];
    pthread_t boat_threads[boats];

    int car_ids[cars];
    int boat_ids[boats];

    for (int i = 0; i < cars; i++) {
        car_ids[i] = i + 1;
        pthread_create(&car_threads[i], NULL, car_pass, (void*)&car_ids[i]);
    }

    for (int i = 0; i < boats; i++) {
        boat_ids[i] = i + 1;
        pthread_create(&boat_threads[i], NULL, boat_pass, (void*)&boat_ids[i]);
    }

    for (int i = 0; i < cars; i++) {
        pthread_join(boat_threads[i], NULL);
    }

    for (int i = 0; i < boats; i++) {
        pthread_join(boat_threads[i], NULL);
        
    }

    pthread_mutex_destroy(&bridge_lock);
    pthread_cond_destroy(&bridge_available);

    return 0;
}
