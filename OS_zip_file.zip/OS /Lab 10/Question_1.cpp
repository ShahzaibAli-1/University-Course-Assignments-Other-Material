#include<iostream>
#include<pthread.h>
#include<unistd.h>

using namespace std;
int fuel = 0;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t fuel_check;

void * fuelstation(void*){
for(int i= 0 ; i<5;i++){
    pthread_mutex_lock(&lock);
    fuel+=100;
    cout<<"Fuel Filled: "<<fuel<<"\n";
    pthread_mutex_unlock(&lock);
    pthread_cond_signal(&fuel_check);
}
pthread_exit(NULL);
}

void * car(void*){
    pthread_mutex_lock(&lock);
    sleep(2);
while(fuel<40){
    pthread_cond_wait(&fuel_check, &lock);
}
fuel-=40;
cout<<"Got fuel: "<<fuel<<endl;
    pthread_mutex_unlock(&lock);

pthread_exit(NULL);
}


int main(){

pthread_t tid[5];
pthread_create(&tid[1], NULL,fuelstation, NULL);
pthread_create(&tid[2], NULL,car, NULL);
pthread_create(&tid[3], NULL,car, NULL);
pthread_create(&tid[4], NULL,car, NULL);

pthread_mutex_destroy(&lock);
pthread_exit(NULL);

    return 0;
}