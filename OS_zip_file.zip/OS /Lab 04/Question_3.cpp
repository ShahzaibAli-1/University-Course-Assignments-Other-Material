#include<iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>  
#include <cstdlib>  

using namespace std;

int main(){

int num1, num2;
int max, status;
pid_t pid;
cout<<"Enter the first number: ";
cin>>num1;
cout<<"Enter the second number: ";
cin>>num2;
 pid = fork();
if(pid==0){
    if(num1>=num2){
        max = num1;
    }
    else if(num1<=num2){
        max  = num2;
    }
    cout<<"The max number is: "<<max;
    exit(max);
}
else{

     wait(&status);

        
            max = WEXITSTATUS(status);
        
        

        pid = fork();

        

        if (pid == 0) {

            if (num1% 2 == 0 && num2%2==0) {

                cout<<"\n"<<num1<<" and "<<num2<<" is even"<<endl;
            } else {
                if(num1%2==0){
                    cout<<"\n"<<num1<<" is even"<<endl;
                }
                else if(num2%2==0){
                    cout<<"\n"<<num2<<" is even"<<endl;
                }
                else{
                    cout<<" No number is even"<<endl;
                }

            }
            exit(EXIT_SUCCESS);
        } else {

            wait( &status);

            if (!WIFEXITED(status)) {
                printf("Child process did not terminate normally\n");
                exit(EXIT_FAILURE);
            }
        }
}

    return 0;
}