#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>  
#include <cstdlib>  

using namespace std;

int main(){
    int a, b, c, d, e, f;
    cin >> a >> b >> c >> d >> e >> f;

    double x;
    pid_t pid1, pid2, pid3;
    int status1, status2, status3;
    int ans1, ans2, ans3;

    pid1 = fork();
    if (pid1 == 0) {
        // Child process 1
        exit(a * b);
    }
    
    else if (pid1 > 0) {
        waitpid(pid1, &status1, 0);
        ans1 = WIFEXITED(status1) ? WEXITSTATUS(status1) : 0;

        pid2 = fork();
        if (pid2 == 0) {
            // Child process 2
            exit(c / d);
        }
        else if (pid2 > 0) {
            waitpid(pid2, &status2, 0);
            ans2 = WIFEXITED(status2) ? WEXITSTATUS(status2) : 0;

            pid3 = fork();
            if (pid3 == 0) {
                // Child process 3
                exit((e - f));
            }


            else if (pid3 > 0) {
                waitpid(pid3, &status3, 0);
                ans3 = WIFEXITED(status3) ? WEXITSTATUS(status3) : 0;
            }
        }
    }
    
    if (pid1 > 0 && pid2 > 0 && pid3 > 0) {
        x = ans1 + ans2 + ans3;
        cout << x << endl;
    }

    return 0;
}
