#include <iostream>
#include <sys/wait.h>
#include <unistd.h>

#include <stdlib.h>  
using namespace std;

int main() {
    string s1, s2;


    getline(cin, s1);
    getline(cin, s2);

    pid_t pid = fork();

    if (pid < 0) {

        cout << "Fork failed!" << endl;
        return 1;
    }

    if (pid == 0) {

        if (s1 == s2) {
            exit(1);  
        } else {
            exit(0);  
        }
    } else {

        int status;
        wait( &status);  

        
            int exit_status = WEXITSTATUS(status);
            if (exit_status == 1) {
                cout << "Equal" << endl;
            } 
            else if (exit_status == 0) {
                cout << "Not Equal" << endl;
            } 
            else {
                cout << "Error" << endl;
            }
        
    }

    return 0;
}
