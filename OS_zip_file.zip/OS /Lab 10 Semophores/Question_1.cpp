#include <iostream>
#include <thread>
#include <semaphore.h>
#include <unistd.h> 

using namespace std;
int water_available = 0;  
binary_semaphore water_lock(1); 

//water filter function
void water_filter() {
    while (true) {
        water_lock.acquire(); 
        water_available += 10;
        cout << "Filter added 10L of water. Total available: " << water_available << "L\n";
        water_lock.release();
        sleep(1); 
    }
}

//person fetching water
void person(int id) {
    while (true) {
        water_lock.acquire(); 
        if (water_available >= 5) {
            water_available -= 5;
            cout << "Person " << id << " took 5L of water. Remaining: " << water_available << "L\n";
        } else {
            cout << "Person " << id << " waiting for water.\n";
        }
        water_lock.release(); 
        sleep(1); 
    }
}

int main() {
    thread filter_thread(water_filter);

    thread people[5];
    for (int i = 0; i < 5; ++i) {
        people[i] = thread(person, i + 1);
    }

    filter_thread.join();
    for (int i = 0; i < 5; ++i) {
        people[i].join();
    }

    return 0;
}
