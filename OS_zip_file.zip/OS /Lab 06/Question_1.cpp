#include <iostream>
#include <unistd.h>
#include <cstring>
#include <cstdlib>

using namespace std;

const int BUFFER_SIZE = 100;

bool isExitCommand(const char* str) {
    return str[0] == 'e' && str[1] == 'x' && str[2] == 'i' && str[3] == 't' && str[4] == '\0';
}

int main() {
    int p1[2]; 
    int p2[2]; 

    if (pipe(p1) == -1 || pipe(p2) == -1) {
        perror("Pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid_t process_id = fork(); 

    if (process_id > 0) { 
        char parent_message[BUFFER_SIZE];

        close(p1[0]); 
        close(p2[1]); 

        while (true) {
            cout << "Parent: ";
            cin >> parent_message; 
            write(p1[1], parent_message, strlen(parent_message) + 1);

            if (isExitCommand(parent_message)) {
                break; 
            }

            char child_response[BUFFER_SIZE];
            read(p2[0], child_response, sizeof(child_response));
            cout << "Child: " << child_response << endl;
        }

        close(p1[1]);
        close(p2[0]);
    } else if (process_id == 0) { 
        char child_message[BUFFER_SIZE];
        close(p1[1]); 
        close(p2[0]); 

        while (true) {
            read(p1[0], child_message, sizeof(child_message));
            cout << "Parent: " << child_message << endl;

            if (isExitCommand(child_message)) {
                break; 
            }

            cout << "Child: ";
            cin >> child_message; 
            write(p2[1], child_message, strlen(child_message) + 1);
        }

        close(p1[0]);
        close(p2[1]);
    } else {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    return 0; 
}
