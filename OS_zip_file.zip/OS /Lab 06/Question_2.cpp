#include <iostream>
#include <unistd.h>
#include <cstring>
#include <cstdlib>

#define BUFFER_SIZE 100

using namespace std;

void reverseString(char* str) {
    int n = strlen(str);
    for (int i = 0; i < n / 2; i++) {
        swap(str[i], str[n - i - 1]);
    }
}

bool areStringsEqual(const char* str1, const char* str2) {
    while (*str1 && *str2) {
        if (*str1 != *str2) {
            return false;
        }
        str1++;
        str2++;
    }
    return *str1 == *str2; 
}

int main() {
    int p1[2];
    int p2[2];


    if (pipe(p1) == -1 || pipe(p2) == -1) {
        perror("Pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid_t process_id = fork();

    if (process_id > 0) {
        char parent_message[BUFFER_SIZE];
        close(p1[0]);
        close(p2[1]);

        cout << "Enter string:";
        cin >> parent_message;
        cout << "Parent process sending string to child process: " << parent_message << endl;
        write(p1[1], parent_message, strlen(parent_message) + 1);

        char child_response[BUFFER_SIZE];
        read(p2[0], child_response, sizeof(child_response));
        cout << "Parent process received the reversed string: " << child_response << endl;

        char expected_reversed[BUFFER_SIZE];
        strcpy(expected_reversed, parent_message);
        reverseString(expected_reversed);

        cout << "Reversed string: " << child_response << " (";
        cout << (areStringsEqual(child_response, expected_reversed) ? "Correct" : "Incorrect") << ")" << endl;

        close(p1[1]);
        close(p2[0]);
    } else if (process_id == 0) {
        char child_message[BUFFER_SIZE];
        close(p1[1]);
        close(p2[0]);

        read(p1[0], child_message, sizeof(child_message));
        cout << "Child process received string: " << child_message << endl;

        cout << "Child process reversing the string" << endl;
        reverseString(child_message);
        cout << "Child process sending reversed string back to the parent: " << child_message << endl;

        write(p2[1], child_message, strlen(child_message) + 1);

        close(p1[0]);
        close(p2[1]);
    } else {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    return 0;
}
