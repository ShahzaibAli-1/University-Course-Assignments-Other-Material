#include<iostream>
#include<unistd.h>
#include<threads.h>
#include<ctime>
using namespace std;
int ROLL_NUMBER_DIGIT = 6;
int ROLL_NUMBER = 0576;

//function for creating board size
int create_board_size(){
srand(time(0));
int final_number = 0;
int random_number = 10 * rand()%99;
random_number *= ROLL_NUMBER_DIGIT;
final_number = ROLL_NUMBER /random_number; 
final_number%=25;
if(final_number<10){
    final_number += 15;
}
return final_number;

}

//function for creation of board
void create_board(int size, int **arr){
   for(int i =0  ;i<size;i++){

        for(int j = 0 ;j<size;j++){
          int is_item_present = rand()%2;
            if(arr[i][j]==0 && is_item_present){
                arr[i][j] =1;
                
            }
            else{
                arr[i][j] = 0;
            }
        }
    }

}

void show_board(int * arr[], int size){
for(int i= 0;i<size;i++){
for(int j = 0 ;j<size;j++){
    cout<<arr[i][j]<<" ";
}
cout<<"\n";
}
}

int move_player_1(int position_player_1[2], int**arr, int size, int points, char key){
        if(key=='w'){
        position_player_1[1]+=1; 
    }
    if(key=='a'){
        position_player_1[0]-=1;
    }
    if(key=='s'){
        position_player_1[0]+=1;

    }
    if(key=='d'){
        position_player_1[1]+=-1;
    }

    if(arr[position_player_1[0]][position_player_1[1]] ==1)
    {arr[position_player_1[0]][position_player_1[1]] = 0;
    points++;
        }


return points;
}
int move_player_2(int position_player_2[2], int ** arr, int size, int points, char key){
    if(key=='w'){
        position_player_2[1]+=1; 
    }
    if(key=='a'){
        position_player_2[0]-=1;
    }
    if(key=='s'){
        position_player_2[0]+=1;

    }
    if(key=='d'){
        position_player_2[1]-=1;
    }

    if(arr[position_player_2[0]][position_player_2[1]] ==1)
    {arr[position_player_2[0]][position_player_2[1]] = 0;
    points++;
        }

    return points;

}
bool check_game_end(int board_size, int **arr){
    for(int i=  0;i<board_size;i++){
        for(int j =0  ;j<board_size;j++){
            if(arr[i][j] = 1)
            return 0;
        }
    }
    return 1;
}

int main(){

int board_size = create_board_size();
cout<<board_size<<"\n";
int **arr = new int *[board_size] ;
for(int i = 0;i<board_size;i++){
    arr[i] = new int (board_size);
}
create_board(board_size, arr);
show_board( arr,board_size);
    return 0;
}