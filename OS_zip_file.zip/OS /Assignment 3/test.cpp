#include <iostream>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <termios.h>  // For capturing key presses on Unix systems

using namespace std;

int ROLL_NUMBER_DIGIT = 6;
int ROLL_NUMBER = 0576;

//function to create board size
int create_board_size() {
    srand(time(0));
    int final_number = 0;
    int random_number = 10 + rand() % 90;
    random_number *= ROLL_NUMBER_DIGIT;
    final_number = ROLL_NUMBER / random_number;
    final_number %= 25;
    if (final_number < 10) {
        final_number += 15;
    }
    return final_number;
}


void create_board(int size, int **arr) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            int is_item_present = rand() % 2;
            arr[i][j] = is_item_present;
        }
    }
}


char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror("tcsetattr ~ICANON");
    return buf;
}

//function to display the board with players shown as P and S
void show_board(int **arr, int size, int position_player_1[2], int position_player_2[2]) {
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            if (i == position_player_1[0] && j == position_player_1[1]) {
                cout << "P ";  
            } else if (i == position_player_2[0] && j == position_player_2[1]) {
                cout << "S ";  
            } else {
                cout << arr[i][j] << " ";
            }
        }
        cout << "\n";
    }
}

//function to move a player based on WASD keys
int move_player(int position[2], int **arr, int size, int points, char key) {
    int new_x = position[0];
    int new_y = position[1];


    if (key == 'w' && new_x > 0) new_x--;       // Move up
    if (key == 's' && new_x < size - 1) new_x++; // Move down
    if (key == 'a' && new_y > 0) new_y--;        // Move left
    if (key == 'd' && new_y < size - 1) new_y++; // Move right

    //check if player moved to a square with an item
    if (arr[new_x][new_y] == 1) {
        arr[new_x][new_y] = 0;
        points++;
    }

    //update player position
    position[0] = new_x;
    position[1] = new_y;
    return points;
}


bool check_game_end(int board_size, int **arr) {
    for (int i = 0; i < board_size; i++) {
        for (int j = 0; j < board_size; j++) {
            if (arr[i][j] == 1) return false;
        }
    }
    return true;
}

int main() {
    srand(time(0));
    int board_size = create_board_size();
    cout << "Board size: " << board_size << "\n";

    //dynamically allocate the 2D array for the game board
    int **arr = new int*[board_size];
    for (int i = 0; i < board_size; i++) {
        arr[i] = new int[board_size]();
    }
    create_board(board_size, arr);
    
    //initialize player positions and points
    int position_player_1[2] = {0, 0};  
    int position_player_2[2] = {board_size - 1, board_size - 1};  
    int points_player_1 = 0, points_player_2 = 0;


    while (!check_game_end(board_size, arr)) {

        show_board(arr, board_size, position_player_1, position_player_2);
        cout << "Player 1 Points: " << points_player_1 << " | Position: (" << position_player_1[0] << ", " << position_player_1[1] << ")\n";
        cout << "Player 2 Points: " << points_player_2 << " | Position: (" << position_player_2[0] << ", " << position_player_2[1] << ")\n";


        cout << "Player 1, Enter move (WASD): ";
        char key1 = getch();
        points_player_1 = move_player(position_player_1, arr, board_size, points_player_1, key1);


        cout << "Player 2, Enter move (WASD): \n";
        char key2 = getch();
        points_player_2 = move_player(position_player_2, arr, board_size, points_player_2, key2);
    }


    cout << "\nGame over! All items collected.\n";
    cout << "Final Scores:\n";
    cout << "Player 1: " << points_player_1 << " points\n";
    cout << "Player 2: " << points_player_2 << " points\n";

    if (points_player_1 > points_player_2) {
        cout << "Player 1 wins!\n";
    } else if (points_player_2 > points_player_1) {
        cout << "Player 2 wins!\n";
    } else {
        cout << "It's a tie!\n";
    }

    //free dynamically allocated memory
    for (int i = 0; i < board_size; i++) {
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}
