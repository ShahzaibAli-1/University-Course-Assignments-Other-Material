#include <iostream>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <pthread.h>
#include <termios.h>  // For capturing key presses on Unix systems
using namespace std;

int ROLL_NUMBER_DIGIT = 6;
int ROLL_NUMBER = 0576;

int **arr;
int board_size;
int points_player_1 = 0, points_player_2 = 0;
int position_player_1[2] = {0, 0};
int position_player_2[2];

int pipe_fd_1[2];  
int pipe_fd_2[2];  

int create_board_size() {
    srand(time(0));
    int final_number = 0;
    int random_number = 10 + rand() % 90;
    random_number *= ROLL_NUMBER_DIGIT;
    final_number = ROLL_NUMBER / random_number;
    final_number %= 25;
    if (final_number < 10) {
        final_number += 15;
    }
    return final_number;
}

void create_board(int size) {
    arr = new int*[size];
    for (int i = 0; i < size; i++) {
        arr[i] = new int[size]();
        for (int j = 0; j < size; j++) {
            arr[i][j] = rand() % 2;
        }
    }
}

char getch() {
    char buf = 0;
    struct termios old = {0};
    if (tcgetattr(0, &old) < 0)
        perror("tcsetattr()");
    old.c_lflag &= ~ICANON;
    old.c_lflag &= ~ECHO;
    if (tcsetattr(0, TCSANOW, &old) < 0)
        perror("tcsetattr ICANON");
    if (read(0, &buf, 1) < 0)
        perror("read()");
    old.c_lflag |= ICANON;
    old.c_lflag |= ECHO;
    if (tcsetattr(0, TCSADRAIN, &old) < 0)
        perror("tcsetattr ~ICANON");
    return buf;
}


void show_board() {
    for (int i = 0; i < board_size; i++) {
        for (int j = 0; j < board_size; j++) {
            if (i == position_player_1[0] && j == position_player_1[1]) {
                cout << "P ";  
            } else if (i == position_player_2[0] && j == position_player_2[1]) {
                cout << "S ";  
            } else {
                cout << arr[i][j] << " ";
            }
        }
        cout << "\n";
    }
    cout << "Player 1 Points: " << points_player_1 << " | Position: (" << position_player_1[0] << ", " << position_player_1[1] << ")\n";
    cout << "Player 2 Points: " << points_player_2 << " | Position: (" << position_player_2[0] << ", " << position_player_2[1] << ")\n";
}

bool check_game_end() {
    for (int i = 0; i < board_size; i++) {
        for (int j = 0; j < board_size; j++) {
            if (arr[i][j] == 1) return false;
        }
    }
    return true;
}

void* player_thread(void* arg) {
    int* player_pos = (int*)arg;
    int fd = (player_pos == position_player_1) ? pipe_fd_1[1] : pipe_fd_2[1];
    char key;

    while (!check_game_end()) {
        cout << "\nPlayer " << ((fd == pipe_fd_1[1]) ? "1" : "2") << ", Enter move (WASD): \n";
        cin >> key;

        int new_x = player_pos[0];
        int new_y = player_pos[1];

        if (key == 'w' && new_x > 0) new_x--;       // Move up
        if (key == 's' && new_x < board_size - 1) new_x++; // Move down
        if (key == 'a' && new_y > 0) new_y--;        // Move left
        if (key == 'd' && new_y < board_size - 1) new_y++; // Move right

        if (arr[new_x][new_y] == 1) {
            arr[new_x][new_y] = 0;
            write(fd, "1", 1);  // Signal item collected
        } else {
            write(fd, "0", 1);  // Signal movement only
        }

        player_pos[0] = new_x;
        player_pos[1] = new_y;
    }

    return NULL;
}

int main() {
    srand(time(0));
    board_size = create_board_size();
    cout << "Board size: " << board_size << "\n";

    create_board(board_size);
    position_player_2[0] = board_size - 1;
    position_player_2[1] = board_size - 1;

    pipe(pipe_fd_1);
    pipe(pipe_fd_2);

    pthread_t player1, player2;
    pthread_create(&player1, NULL, player_thread, position_player_1);
    pthread_create(&player2, NULL, player_thread, position_player_2);

    char buffer;

    while (!check_game_end()) {
        show_board();

        // Read from player 1's pipe
        if (read(pipe_fd_1[0], &buffer, 1) > 0) {
            if (buffer == '1') points_player_1++;
        }

        // Read from player 2's pipe
        if (read(pipe_fd_2[0], &buffer, 1) > 0) {
            if (buffer == '1') points_player_2++;
        }
    }

    cout << "\nGame over! All items collected.\n";
    cout << "Final Scores:\n";
    cout << "Player 1: " << points_player_1 << " points\n";
    cout << "Player 2: " << points_player_2 << " points\n";

    if (points_player_1 > points_player_2) {
        cout << "Player 1 wins!\n";
    } else if (points_player_2 > points_player_1) {
        cout << "Player 2 wins!\n";
    } else {
        cout << "It's a tie!\n";
    }

    for (int i = 0; i < board_size; i++) {
        delete[] arr[i];
    }
    delete[] arr;

    pthread_join(player1, NULL);
    pthread_join(player2, NULL);
    close(pipe_fd_1[0]);
    close(pipe_fd_1[1]);
    close(pipe_fd_2[0]);
    close(pipe_fd_2[1]);

    return 0;
}
