#include <iostream>
#include <fstream>
#include <cstring>
#include <pthread.h>
#include <unordered_map>
#include <vector>
#include <mutex>

using namespace std;

#define MAX_WORDS 100
#define MAX_LENGTH 50
#define NUM_THREADS 4

mutex mtx;

struct MapData {
    const char* inputText;
    char words[MAX_WORDS][MAX_LENGTH];
    int counts[MAX_WORDS];
    int wordCount;
};

struct ShuffleData {
    char words[MAX_WORDS][MAX_LENGTH];
    int counts[MAX_WORDS];
    int wordCount;
    char groupedWords[MAX_WORDS][MAX_LENGTH];
    int groupedCounts[MAX_WORDS];
    int groupedWordCount;
};

struct ReduceData {
    char words[MAX_WORDS][MAX_LENGTH];
    int counts[MAX_WORDS];
    int wordCount;
    char finalWords[MAX_WORDS][MAX_LENGTH];
    int finalCounts[MAX_WORDS];
    int finalWordCount;
};

void* mapPhase(void* arg) {
    MapData* data = (MapData*)arg;
    data->wordCount = 0;
    const char* word = strtok(const_cast<char*>(data->inputText), " ");
    while (word != NULL) {
        strcpy(data->words[data->wordCount], word);
        data->counts[data->wordCount] = 1;
        data->wordCount++;
        word = strtok(NULL, " ");
    }
    return nullptr;
}

void* shufflePhase(void* arg) {
    ShuffleData* data = (ShuffleData*)arg;
    data->groupedWordCount = 0;
    unordered_map<string, int> wordMap;

    for (int i = 0; i < data->wordCount; ++i) {
        
        mtx.lock();
        wordMap[data->words[i]] += data->counts[i];
        mtx.unlock();
    }

    //transfer grouped results to the final arrays safely
    for (const auto& entry : wordMap) {
        mtx.lock();
        strcpy(data->groupedWords[data->groupedWordCount], entry.first.c_str());
        data->groupedCounts[data->groupedWordCount] = entry.second;
        data->groupedWordCount++;
        mtx.unlock();
    }
    return nullptr;
}



void* reducePhase(void* arg) {
    ReduceData* data = (ReduceData*)arg;
    data->finalWordCount = 0;

    for (int i = 0; i < data->wordCount; ++i) {
        bool found = false;


        {
            lock_guard<mutex> lock(mtx);
            
            for (int j = 0; j < data->finalWordCount; ++j) {
                if (strcmp(data->words[i], data->finalWords[j]) == 0) {
                    data->finalCounts[j] += data->counts[i];
                    found = true;
                    break;
                }
            }


            if (!found) {
                strcpy(data->finalWords[data->finalWordCount], data->words[i]);
                data->finalCounts[data->finalWordCount] = data->counts[i];
                data->finalWordCount++;
            }
        }
    }

    return nullptr;
}



void parseExpectedOutput(const char* expectedText, char words[MAX_WORDS][MAX_LENGTH], int counts[MAX_WORDS], int& expectedCount) {
    expectedCount = 0;
    char temp[256];
    strcpy(temp, expectedText);

    const char* token = strtok(temp, "() ,\n");
    while (token != NULL) {
        strcpy(words[expectedCount], token);
        token = strtok(NULL, "() ,\n");
        counts[expectedCount++] = atoi(token);
        token = strtok(NULL, "() ,\n");
    }
}

bool compareResults(char actualWords[MAX_WORDS][MAX_LENGTH], int actualCounts[MAX_WORDS], int actualCount,
                    char expectedWords[MAX_WORDS][MAX_LENGTH], int expectedCounts[MAX_WORDS], int expectedCount) 
{
    if (actualCount != expectedCount) return false;

    for (int i = 0; i < actualCount; ++i) {
        bool found = false;
        for (int j = 0; j < expectedCount; ++j) {
            if (strcmp(actualWords[i], expectedWords[j]) == 0 && actualCounts[i] == expectedCounts[j]) {
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    return true;
}

void printResults(char words[MAX_WORDS][MAX_LENGTH], int counts[MAX_WORDS], int wordCount) {
    for (int i = 0; i < wordCount; ++i) {
        cout << "(" << words[i] << ", " << counts[i] << ") ";
    }
    cout << endl;
}

int main() {
    ifstream testFile("test_cases.txt");
    if (!testFile.is_open()) {
        cerr << "Failed to open test cases file." << endl;
        return 1;
    }

    char line[256], inputText[256], expectedText[1024];
    int testCaseNumber = 1;

    while (testFile.getline(line, sizeof(line))) {
        if (strncmp(line, "Input:", 6) == 0) {
            strcpy(inputText, line + 7); //extract 
        } 
        else if (strncmp(line, "Expected Output:", 16) == 0) {
            strcpy(expectedText, "");
            while (testFile.getline(line, sizeof(line)) && strlen(line) > 0) {
                strcat(expectedText, line);
                strcat(expectedText, "\n");
            }

            //mapping Phase
            MapData mapData;
            mapData.inputText = inputText;
            pthread_t mapThread;
            pthread_create(&mapThread, NULL, mapPhase, &mapData);
            pthread_join(mapThread, NULL);

            //shuffling Phase
            ShuffleData shuffleData;
            shuffleData.wordCount = mapData.wordCount;
            memcpy(shuffleData.words, mapData.words, sizeof(mapData.words));
            memcpy(shuffleData.counts, mapData.counts, sizeof(mapData.counts));
            pthread_t shuffleThread;
            pthread_create(&shuffleThread, NULL, shufflePhase, &shuffleData);
            pthread_join(shuffleThread, NULL);

            //reduction Phase
            ReduceData reduceData;
            reduceData.wordCount = shuffleData.groupedWordCount;
            memcpy(reduceData.words, shuffleData.groupedWords, sizeof(shuffleData.groupedWords));
            memcpy(reduceData.counts, shuffleData.groupedCounts, sizeof(shuffleData.groupedCounts));
            pthread_t reduceThread;
            pthread_create(&reduceThread, NULL, reducePhase, &reduceData);
            pthread_join(reduceThread, NULL);

            //parse expected output
            char expectedWords[MAX_WORDS][MAX_LENGTH];
            int expectedCounts[MAX_WORDS];
            int expectedWordCount = 0;
            parseExpectedOutput(expectedText, expectedWords, expectedCounts, expectedWordCount);

            //print actual and expected results
            cout << "Test Case " << testCaseNumber++ << ":" << endl;
            cout << "Expected: ";
            printResults(expectedWords, expectedCounts, expectedWordCount);

            cout << "Actual: ";
            printResults(reduceData.finalWords, reduceData.finalCounts, reduceData.finalWordCount);

            //compare results
            if (compareResults(reduceData.finalWords, reduceData.finalCounts, reduceData.finalWordCount,
                               expectedWords, expectedCounts, expectedWordCount)) {
                cout << "\nTest Case " << testCaseNumber-1 << ": Passed" << endl << endl << endl;
            } else {
                cout << "\nTest Case " << testCaseNumber-1 << ": Failed" << endl << endl << endl;
            }
        }
    }

    return 0;
}
