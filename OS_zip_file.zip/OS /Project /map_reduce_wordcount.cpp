#include <iostream>
#include <vector>
#include <pthread.h>
#include <sstream>
#include <unordered_map>
#include <string>
#include <mutex>
#include <algorithm>

using namespace std;


unordered_map<string, int> wordCountMap; 
mutex mtx;

// Helper function for logging
template <typename T>
void log(const T& message) {
    lock_guard<mutex> guard(mtx);
    cout << message << endl;
}

// Map phase function: splits the chunk into words and counts them
void* mapPhase(void* arg) {
    string* chunk = (string*)arg;
    log("Mapping chunk: " + *chunk);
    stringstream ss(*chunk);
    string word;

    // Temporary local map to store counts in this thread
    unordered_map<string, int> localMap;

    while (ss >> word) {
        localMap[word] += 1;
    }

    // Lock mutex to update global map
    lock_guard<mutex> guard(mtx);
    // Merge localMap into global wordCountMap
    for (const auto& entry : localMap) {
        wordCountMap[entry.first] += entry.second;
    }

    log("Finished mapping chunk: " + *chunk);
    return nullptr;
}

// Reduce phase: sums up the counts for each word (already done in mapPhase)
void reducePhase() {
    log("Starting reduce phase");
    for (const auto& entry : wordCountMap) {
        cout << "(" << entry.first << ", " << entry.second << ")" << endl;
    }
    log("Reduce phase completed");
}

// Function to split input into chunks for map phase
void splitInput(const string& input, vector<string>& chunks, size_t chunkSize) {
    log("Splitting input into chunks");
    size_t start = 0;
    while (start < input.size()) {
        size_t end = min(start + chunkSize, input.size());
        // Make sure chunks don't split words in the middle
        if (end < input.size() && input[end] != ' ') {
            while (end > start && input[end] != ' ') {
                --end;
            }
        }
        chunks.push_back(input.substr(start, end - start));
        log("Created chunk: " + chunks.back());
        start = end + 1; // Move past the space
    }
    log("Finished splitting input into chunks");
}
#ifndef UNIT_TEST
int main() {
    string input;  // Example input
    // pizza burger pasta pasta pizza burger apple
    cout << "Enter input string: ";
    getline(cin, input);

    size_t chunkSize = 10; // Split the input into chunks of 10 characters
    vector<string> chunks;

    // Step 1: Split input into chunks for parallel processing
    splitInput(input, chunks, chunkSize);

    // Step 2: Create threads for Map phase
    log("Starting map phase with threads");
    vector<pthread_t> threads(chunks.size());
    for (size_t i = 0; i < chunks.size(); ++i) {
        pthread_create(&threads[i], nullptr, mapPhase, (void*)&chunks[i]);
    }

    // Wait for all threads to finish
    for (size_t i = 0; i < chunks.size(); ++i) {
        pthread_join(threads[i], nullptr);
    }
    log("Map phase completed");

    // Step 3: Reduce phase to aggregate results
    reducePhase();


    return 0;
}
#endif