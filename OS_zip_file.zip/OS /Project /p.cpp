#include <iostream>
#include <vector>
#include <pthread.h>
#include <sstream>
#include <unordered_map>
#include <string>
#include <mutex>
#include <algorithm>

using namespace std;

// Global variables for storing intermediate results
unordered_map<string, int> wordCountMap; // Stores word counts
mutex mtx; // Mutex to handle synchronization

// Map phase function: splits the chunk into words and counts them
void* mapPhase(void* arg) {
    string* chunk = (string*)arg;
    stringstream ss(*chunk);
    string word;

    // Temporary local map to store counts in this thread
    unordered_map<string, int> localMap;

    while (ss >> word) {
        localMap[word] += 1;
    }

    // Lock mutex to update global map
    lock_guard<mutex> guard(mtx);
    // Merge localMap into global wordCountMap
    for (const auto& entry : localMap) {
        wordCountMap[entry.first] += entry.second;
    }

    return nullptr;
}

// Reduce phase: sums up the counts for each word (already done in mapPhase)
void reducePhase() {
    for (const auto& entry : wordCountMap) {
        cout << "(" << entry.first << ", " << entry.second << ")" << endl;
    }
}

// Function to split input into chunks for map phase
void splitInput(const string& input, vector<string>& chunks, size_t chunkSize) {
    size_t start = 0;
    while (start < input.size()) {
        size_t end = min(start + chunkSize, input.size());
        // Make sure chunks don't split words in the middle
        if (end < input.size() && input[end] != ' ') {
            while (end > start && input[end] != ' ') {
                --end;
            }
        }
        chunks.push_back(input.substr(start, end - start));
        start = end + 1; // Move past the space
    }
}

int main() {
    string input ;  // Example input
    // pizza burger pasta pasta pizza burger apple
    getline(cin, input);
    size_t chunkSize = 10; // Split the input into chunks of 10 characters
    vector<string> chunks;

    // Step 1: Split input into chunks for parallel processing
    splitInput(input, chunks, chunkSize);

    // Step 2: Create threads for Map phase
    vector<pthread_t> threads(chunks.size());
    for (size_t i = 0; i < chunks.size(); ++i) {
        pthread_create(&threads[i], nullptr, mapPhase, (void*)&chunks[i]);
    }

    // Wait for all threads to finish
    for (size_t i = 0; i < chunks.size(); ++i) {
        pthread_join(threads[i], nullptr);
    }

    // Step 3: Reduce phase to aggregate results
    reducePhase();

    return 0;
}

