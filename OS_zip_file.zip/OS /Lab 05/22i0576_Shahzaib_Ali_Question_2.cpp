#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>

using namespace std;

int main() {
    string input;
    
    while (true) {

        cout << "Enter a command (pwd, ls, date, cat, or exit): ";
        cin >> input;


        if (input == "Exit" || input=="exit") {
            cout << "Exiting program." << endl;
            break;
        }


        pid_t pid = fork();
        
        if (pid < 0) {
            cout<<"Fork fail"<<endl;
            continue;
        } 
        
        if (pid == 0) {

            if (input == "pwd") {

                execl("/bin/pwd", "pwd", (char *)NULL);

            } 
            else if (input == "ls") {

                execlp("ls", "ls", "-l", (char *)NULL);

            } 
            else if (input == "date") {

                char *args[] = { (char *)"date", (char *)NULL };
                execv("/bin/date", args);
                
            } 
            else if (input == "cat") {

                char *args[] = { (char *)"cat", (char *)"/etc/os-release", (char *)NULL };  
                execvp("cat", args);

            } 
            else {

                cout << "Invalid argument" << endl;
 
            }
        } else {

            wait(NULL);
        }
    }

    return 0;
}
