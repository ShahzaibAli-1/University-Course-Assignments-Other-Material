#include<iostream>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<cstring>

using namespace std;


int main(){
    int fd = open("PIPE2", O_RDONLY);    
    char buffer[50];
    if(fd<0){
        cout<<"Error opening file";
        return 1;
    }
    read(fd, buffer, strlen(buffer)+1 );
    // cout<<"String Converted: \n";
    // char letter;
    // string test_str = " ";
    // for(int i = 0 ;buffer[i]!='\0';i++){
    //     test_str += to_string(buffer[i])  + " ";
    //     // cout<<int(buffer[i])<<" ";
    // }
    // cout<<test_str<<endl;
    cout<<buffer<<endl;
    close(fd);


    // write(fd, buffer, strlen(buffer)+1);


    return 0;
}