#include<iostream>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<cstring>

using namespace std;


int main(){
    char buffer[30];
    char arr[20];
    cout<<"Enter the string: ";
    cin>>arr;
    mkfifo("PIPE", 0666);
    
    int fd = open("PIPE", O_WRONLY);
    
    strcpy(buffer, arr);
    // read(fd, buffer, strlen(buffer)+1 );
    write(fd, buffer, strlen(buffer)+1);


    return 0;
}