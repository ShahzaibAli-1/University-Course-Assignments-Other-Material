#include<iostream>
#include<unistd.h>
#include<sys/wait.h>
#include<cstring>

using namespace std;


int main(){
string test_1, test_2;

cout<<"Enter the string 1: ";
getline(cin,test_1);
cout<<"Enter the string 2: ";
getline(cin, test_2);

pid_t p1 = fork();

if(p1==0){

if(test_1 == test_2){
    exit(1);
}
else{
    exit(0);
}

}
else
{
int status;
wait(&status);
if(WEXITSTATUS(status)){
    int exit_status = WEXITSTATUS(status);
    cout<<"The exit status code is: "<<exit_status<<"\n";

}

}

    return 0;
}