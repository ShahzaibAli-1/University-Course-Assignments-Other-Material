#include<iostream>
#include<unistd.h>
#include<stdlib.h>
using namespace std;

int main(){

    //It takes path address and it takes to the given file_location
    // execl("/home/shahzaib/OS /Lab 05/test_file", "test_file",  NULL);

    // //It takes path file name and return file
    // execlp("/home/shahzaib/OS /Lab 05/test_file", "test_file", NULL, (char* )NULL);
    
    // //It is array of args variable
    // char *args[] = { (char *)"test_file", (char *)NULL };
    //  execv("/home/shahzaib/OS /Lab 05/test_file", args);
    

    // //env is array of envioronment variables
    // char *env[] = { (char *)"PATH=/bin:/usr/bin:/usr/local/bin", (char *)NULL };
char * args[] = {(char *)"/local/home_part_2/2",(char *) NULL};
    // //execle takes array of Environment variables 
    // execle("/home/shahzaib/OS /Lab 05/test_file", "test_file", (char *)NULL, env);
    
    // // execve takes both an array of arguments and an array of environment variables
    // execve("/home/shahzaib/OS /Lab 05/test_file", args, env);
    return 0;
}