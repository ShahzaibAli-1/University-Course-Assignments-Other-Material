#include<iostream>
#include<unistd.h>
#include<sys/types.h>

using namespace std;


int main(){

pid_t pid1 = fork();


if(pid1==0){
    cout<<"This is p1 child process\n";

    pid_t pid2 = fork();

    if(pid2==0){
        cout<<"This is p2 child process\n";
        pid_t pid3 = fork();
        if(pid3==0){
            cout<<"This is is p3 child process\n";
        }
        else{
            cout<<"This is p3 parent process\n";
        }
    }
    if(pid2>0){
        cout<<"This is p2 parent process";
    }

}
if(pid1>0){
    cout<<"This is p1 parent process\n";
}
    return 0;
}