// #include<iostream>
// #include<unistd.h>
// #include<pthread.h>


// using namespace std;
// pthread_mutex_t mutex_lock = PTHREAD_MUTEX_INITIALIZER;
// pthread_cond_t check_bridge = PTHREAD_COND_INITIALIZER;

// int cars, boats, car_time, boat_time;
// bool car_on_bridge = false, boat_on_bridge = false;
// void *boatpass(void * arg){
// int boat_id = *(int * )arg;
// pthread_mutex_lock(&mutex_lock);
// while(boat_on_bridge){
//     pthread_cond_wait(&check_bridge, &mutex_lock);
// }

// car_on_bridge = true;

// cout<<"boat "<<boat_id <<"\n";

// }

// int main(){
//     cout<<"Enter the number of cars, boats";

//     cin>>cars>>boats>>car_time>>boat_time;
//     pthread_t  car_threads[cars];
//     pthread_t boat_threads[boats];

//     int car_ids[cars];
//     int boat_ids[boats];
//     for (int i = 0;i<cars;i++){
//         car_ids[i] = i+1;
//         pthread_create(&car_threads[i], NULL, car_pass, );
//     }

//     return 0;
// }