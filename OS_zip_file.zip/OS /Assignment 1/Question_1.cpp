#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;

int main() {
    char arr[9] = "SHAHZAIB"; 
    int status;
    int sum = 0;  

    pid_t pidS = fork();
    if (pidS == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[0] 
             << ", ASCII: " << int(arr[0]) << endl;
        exit(int(arr[0]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidH = fork();
    if (pidH == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[1] 
             << ", ASCII: " << int(arr[1]) << endl;
        exit(int(arr[1]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidA = fork();
    if (pidA == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[2] 
             << ", ASCII: " << int(arr[2]) << endl;
        exit(int(arr[2]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidH2 = fork();
    if (pidH2 == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[3] 
             << ", ASCII: " << int(arr[3]) << endl;
        exit(int(arr[3]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidZ = fork();
    if (pidZ == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[4] 
             << ", ASCII: " << int(arr[4]) << endl;
        exit(int(arr[4]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidA2 = fork();
    if (pidA2 == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[5] 
             << ", ASCII: " << int(arr[5]) << endl;
        exit(int(arr[5]));
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidI = fork();
    if (pidI == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[6] 
             << ", ASCII: " << int(arr[6]) << endl;
        exit(int(arr[6]));  
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    pid_t pidB = fork();
    if (pidB == 0) {
        cout << "Child PID: " << getpid() << ", Child: " << arr[7] 
             << ", ASCII: " << int(arr[7]) << endl;
        exit(int(arr[7])); 
    } else {
        wait(&status);
        if (WIFEXITED(status)) sum += WEXITSTATUS(status);
    }


    cout << "Sum of ASCII values: " << sum << endl;

    return 0;
}
