#include <iostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>

using namespace std;

int main() {
    pid_t pid;
    int status;

    // Step 1: Create a child process to execute the ls command
    pid = fork();

    if (pid < 0) {
        cerr << "Fork failed!" << endl;
        exit(1);
    }

    if (pid == 0) {
        // Child process
        // Redirect stdout to "output1.txt"
        int fd = open("output1.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            cerr << "Failed to open output file!" << endl;
            exit(1);
        }
        dup2(fd, STDOUT_FILENO);  // Redirect standard output to the file
        close(fd);  // Close the file descriptor

        // Execute the ls command
        execlp("ls", "ls", "-R", getenv("HOME"), NULL);
        cerr << "Exec for ls failed!" << endl;  // If exec() fails
        exit(1);
    } else {
        // Parent process waits for the child process to finish
        wait(&status);
    }

    // Step 2: Set the PATH environment variable to include the home directory
    char *home = getenv("HOME");
    if (home == nullptr) {
        cerr << "HOME environment variable not found!" << endl;
        exit(1);
    }

    // Update PATH environment variable to include the home directory
    string newPath = string("PATH=") + home + ":" + getenv("PATH");
    putenv(const_cast<char *>(newPath.c_str()));

    // Step 3: Create another child process to execute the grep command
    pid = fork();

    if (pid < 0) {
        cerr << "Fork for grep failed!" << endl;
        exit(1);
    }

    if (pid == 0) {
        // Child process for grep
        // Execute the grep command
        execlp("grep", "grep", "output1.txt", "output1.txt", NULL);
        cerr << "Exec for grep failed!" << endl;  // If exec() fails
        exit(1);
    } else {
        // Parent process waits for the second child process to finish
        wait(&status);
    }

    return 0;
}
