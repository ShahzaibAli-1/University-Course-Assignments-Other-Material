#include <iostream>
#include <sys/wait.h>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include <cctype>

using namespace std;

void reverse_string(char* str) {
    int n = strlen(str);
    for (int i = 0; i < n / 2; ++i) {
        swap(str[i], str[n - i - 1]);
    }
}

void add_two_to_ascii(char* str) {
    for (int i = 0; i < strlen(str); ++i) {
        str[i] = str[i] + 2;
    }
}

void capitalize_string(char* str) {
    for (int i = 0; i < strlen(str); ++i) {
        str[i] = toupper(str[i]);
    }
}

int main() {
    char str[100];
    cout << "Enter a string: ";
    cin.getline(str, 100);

    pid_t pid;
    int status;


    pid = fork();

    if (pid == 0) {

        pid_t reverse_pid = fork();
        
        if (reverse_pid == 0) {
            reverse_string(str);
            cout << "Reversed String: " << str << endl;
            exit(0);
        } else {
            wait(NULL);
            exit(0);
        }
    } else {
        wait(NULL);
    }


    pid = fork();

    if (pid == 0) {

        pid_t length_pid = fork();
        
        if (length_pid == 0) {
            cout << "Length of the String: " << strlen(str) << endl;
            exit(0);
        } else {
            wait(NULL);
            exit(0);
        }
    } else {
        wait(NULL);
    }

    // Task 3: Add 2 to the ASCII values of each character
    pid = fork();

    if (pid == 0) {
        // Child process for adding 2 to ASCII
        pid_t ascii_pid = fork();
        
        if (ascii_pid == 0) {
            add_two_to_ascii(str);
            cout << "String after adding 2 to ASCII: " << str << endl;
            exit(0);
        } else {
            wait(NULL);
            exit(0);
        }
    } else {
        wait(NULL);
    }

 
    pid = fork();

    if (pid == 0) {

        pid_t sort_pid = fork();
        
        if (sort_pid == 0) {
            sort(str, str + strlen(str));
            cout << "Sorted String: " << str << endl;
            exit(0);
        } else {
            wait(NULL);
            exit(0);
        }
    } else {
        wait(NULL);
    }


    pid = fork();

    if (pid == 0) {

        pid_t capitalize_pid = fork();
        
        if (capitalize_pid == 0) {
            capitalize_string(str);
            cout << "Capitalized String: " << str << endl;
            exit(0);
        } else {
            wait(NULL);
            exit(0);
        }
    } else {
        wait(NULL);
    }

    return 0;
}
