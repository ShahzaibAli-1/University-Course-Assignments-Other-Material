#include <iostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>

using namespace std;

int main() {

    char *args1[] = { (char *)"sh", (char *)"-c", (char *)"ls -R $HOME > output1.txt", NULL };
    execvp(args1[0], args1);  //Execute shell command
    cerr << "Exec for ls failed!" << endl;  

    //set the PATH environment variable and execute grep
    char *home = getenv("HOME");
    if (home == nullptr) {
        cerr << "HOME environment variable not found!" << endl;
        return 1;
    }

    //update the PATH environment variable
    string newPath = string("PATH=") + home + ":" + getenv("PATH");
    putenv(const_cast<char *>(newPath.c_str()));

    //Execute the grep command
    char *args2[] = { (char *)"sh", (char *)"-c", (char *)"grep output1.txt *.txt", NULL };
    execvp(args2[0], args2);  
    cerr << "Exec for grep failed!" << endl;  

    // execlp("grep", "grep", "output1.txt", "output1.txt", NULL);
    // cerr << "Exec for grep failed!" << endl;  
    return 0;
}
