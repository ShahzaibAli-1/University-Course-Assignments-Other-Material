#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

struct Node {
    char data;
    int pid;
    int ppid;
    Node* left;
    Node* right;

    Node(char value, int parent_pid) : data(value), left(nullptr), right(nullptr) {
        pid = getpid();
        ppid = parent_pid;
    }
};

// Function to insert a character into the binary tree
Node* insert(Node* root, char value, int parent_pid) {
    if (root == nullptr) {
        return new Node(value, parent_pid);
    }

    if (value < root->data) {
        root->left = insert(root->left, value, root->pid);
    } else {
        root->right = insert(root->right, value, root->pid);
    }
    return root;
}

// Function to display the tree and calculate the ASCII sum
int displayAndSum(Node* node) {
    if (node == nullptr) return 0;

    int leftSum = displayAndSum(node->left);
    int rightSum = displayAndSum(node->right);
    
    // Creating a process to display node information
    pid_t pid = fork();
    if (pid == 0) { // Child process
        // Display node information
        std::cout << "Node " << node->data << ": PPID: " << node->ppid << ", PID: " << node->pid
                  << ", ASCII: " << static_cast<int>(node->data) << std::endl;
        if (leftSum > 0 || rightSum > 0) {
            std::cout << "Node " << node->data << ": My child is ";
            if (leftSum > 0) std::cout << node->left->data << " ";
            if (rightSum > 0) std::cout << node->right->data;
            std::cout << std::endl;
        }
        exit(leftSum + rightSum + static_cast<int>(node->data)); // Return sum to parent
    } else {
        wait(nullptr); // Wait for child to finish
    }

    return leftSum + rightSum + static_cast<int>(node->data);
}

int main() {
    std::string name = "Shahzaib";
    Node* root = nullptr;

    // Insert each character into the binary tree
    for (char c : name) {
        root = insert(root, c, 0);
    }

    // Start the display and sum process from the root
    int totalSum = displayAndSum(root);
    
    // Final output from the parent
    std::cout << "Total ASCII Sum: " << totalSum << std::endl;

    return 0;
}
