#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define FIFO_NAME "/tmp/marks_fifo"
using namespace std;
int main() {

    mkfifo(FIFO_NAME, 0666);

    int total[5], obtained[5];


    cout << "Enter total marks and obtained marks for 5 subjects:\n";
    for (int i = 0; i < 5; ++i) {
        cout << "Subject " << i + 1 << " - Total: ";
        cin >> total[i];
        cout << "Subject " << i + 1 << " - Obtained: ";
        cin >> obtained[i];
    }


    int fd = open(FIFO_NAME, O_WRONLY);


    write(fd, total, sizeof(total));
    write(fd, obtained, sizeof(obtained));

    close(fd); 
    return 0;
}
