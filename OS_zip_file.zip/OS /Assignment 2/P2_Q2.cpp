#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define FIFO_NAME "/tmp/marks_fifo"
using namespace std;

char calculate_grade(float percentage) {
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
}

int main() {

    int total[5], obtained[5];


    mkfifo(FIFO_NAME, 0666);


    int fd = open(FIFO_NAME, O_RDONLY);


    read(fd, total, sizeof(total));
    read(fd, obtained, sizeof(obtained));




    for (int i = 0; i < 5; ++i) {
        float percentage = ((float)obtained[i] / total[i]) * 100;
        char grade = calculate_grade(percentage);
        cout << "Subject " << i + 1 << ": Percentage = " << percentage << "%, Grade = " << grade << endl;
    }


    unlink(FIFO_NAME);
    return 0;
}
