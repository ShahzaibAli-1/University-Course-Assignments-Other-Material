#include <iostream>
using namespace std;
int main() {
    cout << "OS is very easy" <<endl;
    cout<<"What is time"<<endl;
    return 0;
}
