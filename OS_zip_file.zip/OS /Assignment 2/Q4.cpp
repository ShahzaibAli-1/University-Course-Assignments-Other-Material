#include <iostream>
#include <unistd.h>
#include <cstring>
#include <cctype>

using namespace std;

int main() {
    int pipeP1toP2[2], pipeP2toP1[2]; 
    pid_t pid;
    char buffer[1024];
    int sentenceCount = 0;


    if (pipe(pipeP1toP2) == -1 || pipe(pipeP2toP1) == -1) {
        cerr << "Pipe creation failed" << endl;
        return 1;
    }

    pid = fork(); 

    if (pid < 0) {
        cerr << "Fork failed" << endl;
        return 1;
    }

    if (pid == 0) { 
        close(pipeP1toP2[1]); 
        close(pipeP2toP1[0]); 

        string sentence = "";
        char ch;
        while (true) {
            read(pipeP1toP2[0], &ch, 1); 
            if (ch == '#') {
                cout << "P2 exiting..." << endl;
                break;
            }


            sentence += toupper(ch); 

            if (ch == '.' || ch == '?') { 
                cout << "Sentence Received: " << sentence << endl;
                sentenceCount++;


                string sentenceNum = "Sentence number " + to_string(sentenceCount) + " sent to P1\n";
                write(pipeP2toP1[1], sentenceNum.c_str(), sentenceNum.length());

                sentence = ""; 
            }
        }

        close(pipeP1toP2[0]);
        close(pipeP2toP1[1]);
    } else { 
        close(pipeP1toP2[0]);
        close(pipeP2toP1[1]);

        char ch;
        while (true) {
            cout << "Enter text (# to terminate): ";
            cin >> ch; 

            if (ch == '\n') 
            continue; 
            if (isspace(ch)) cout << "Enter text: (Space)" << endl; 

            write(pipeP1toP2[1], &ch, 1); 
            if (ch == '#') {
                cout << "P1 exiting..." << endl;
                break;
            }

            if (ch == '.' || ch == '?') {

                memset(buffer, 0, sizeof(buffer));
                read(pipeP2toP1[0], buffer, sizeof(buffer));
                cout << buffer;
            }
        }

        close(pipeP1toP2[1]);
        close(pipeP2toP1[0]);
    }

    return 0;
}
