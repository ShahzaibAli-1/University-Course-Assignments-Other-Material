#include <iostream>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include<sys/wait.h>


#define MSG_SIZE 100
using namespace std;

void reverse_string(char *str) {
    reverse(str, str + strlen(str));
}

void capitalize_string(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = toupper(str[i]);
    }
}

int main() {
    int pipe1[2], pipe2[2], pipe3[2], pipe4[2]; 
    pid_t child1, child2, child3;


    pipe(pipe1); 
    pipe(pipe2); 
    pipe(pipe3); 
    pipe(pipe4); 

    child1 = fork();

    if (child1 == 0) { 
        close(pipe1[0]); 
        close(pipe4[1]); 

        char message[MSG_SIZE] = "Hello from Child1!";
        cout << "Child1: Sending message to Child2: " << message << endl;
        write(pipe1[1], message, strlen(message) + 1); 
        close(pipe1[1]);


        read(pipe4[0], message, MSG_SIZE);
        cout << "Child1: Received capitalized message: " << message << endl;
        close(pipe4[0]); 

    } else {
        child2 = fork();

        if (child2 == 0) { 
            close(pipe1[1]); 
            close(pipe2[0]); 
            close(pipe3[1]); 
            close(pipe4[0]); 

            char message[MSG_SIZE];


            read(pipe1[0], message, MSG_SIZE);
            cout << "Child2: Received message from Child1: " << message << endl;
            reverse_string(message);
            cout << "Child2: Sending reversed message to Child3: " << message << endl;
            write(pipe2[1], message, strlen(message) + 1); 
            close(pipe2[1]);


            read(pipe3[0], message, MSG_SIZE);
            cout << "Child2: Received message back from Child3: " << message << endl;


            capitalize_string(message);
            cout << "Child2: Sending capitalized message to Child1: " << message << endl;
            write(pipe4[1], message, strlen(message) + 1); 
            close(pipe4[1]); 

            close(pipe1[0]); 
            close(pipe3[0]); 

        } else {
            child3 = fork();

            if (child3 == 0) { 
                close(pipe2[1]); 
                close(pipe3[0]); 

                char message[MSG_SIZE];


                read(pipe2[0], message, MSG_SIZE);
                cout << "Child3: Received reversed message: " << message << endl;


                cout << "Child3: Sending message back to Child2: " << message << endl;
                write(pipe3[1], message, strlen(message) + 1);
                close(pipe3[1]);

                close(pipe2[0]); 

            } else { 
                close(pipe1[1]); 
                close(pipe1[0]);
                close(pipe2[1]);
                close(pipe2[0]);
                close(pipe3[1]);
                close(pipe3[0]);
                close(pipe4[1]);
                close(pipe4[0]);


                wait(NULL);
                wait(NULL);
                wait(NULL);
            }
        }
    }

    return 0;
}
