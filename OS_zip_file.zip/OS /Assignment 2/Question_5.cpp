#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Item {
    string name;
    int quantity;
    double price_per_item;
};

void printReceipt(const vector<Item>& items, double total, double taxedTotal, double finalPrice) {
    cout << "\nProcess 4: Receipt" << endl;
    cout << left << setw(10) << "Items" << "Price" << endl;
    for (const auto& item : items) {
        cout << left << setw(10) << item.name << item.quantity * item.price_per_item << endl;
    }
    cout << left << setw(10) << "Total" << total << endl;
    cout << "After 8% tax " << taxedTotal << endl;
    cout << "After 10% sale " << finalPrice << endl;
}

int main() {
    int pipe1[2];
    int pipe2[2];
    int pipe3[2];

    pipe(pipe1);
    pipe(pipe2);
    pipe(pipe3);

    if (fork() == 0) {
        close(pipe1[0]);
        vector<Item> items = {
            {"eggs", 3, 15.0}, 
            {"bread", 1, 60.0}, 
            {"chocolate", 5, 50.0}
        };

        double total = 0;
        cout << "Process 1: Items Purchased = eggs, bread, chocolate" << endl;
        for (const auto& item : items) {
            double itemTotal = item.quantity * item.price_per_item;
            total += itemTotal;
            cout << item.name << " = " << item.quantity << " x " << item.price_per_item << " = " << itemTotal << endl;
        }
        cout << "Sum = " << total << endl;

        write(pipe1[1], &total, sizeof(total));
        write(pipe1[1], &items[0], items.size() * sizeof(Item));
        close(pipe1[1]);
        exit(0);
    }

    if (fork() == 0) {
        close(pipe1[1]);
        double total;
        read(pipe1[0], &total, sizeof(total));

        double tax = total * 0.08;
        double taxedTotal = total + tax;
        cout << "Process 2: " << total << " * 0.08 = " << tax << ", Taxed sum = " << taxedTotal << endl;

        write(pipe2[1], &taxedTotal, sizeof(taxedTotal));
        close(pipe1[0]);
        close(pipe2[1]);
        exit(0);
    }

    if (fork() == 0) {
        close(pipe2[1]);
        double taxedTotal;
        read(pipe2[0], &taxedTotal, sizeof(taxedTotal));

        double finalPrice;
        double discount = 0;

        if (taxedTotal > 250) {
            discount = taxedTotal * 0.1;
            finalPrice = taxedTotal - discount;
            cout << "Process 3: Price = " << taxedTotal << ", Sale = 0.1, " << taxedTotal << " * 0.1 = " << discount << ", Final price = " << finalPrice << endl;
        } else {
            finalPrice = taxedTotal;
        }

        write(pipe3[1], &finalPrice, sizeof(finalPrice));
        close(pipe2[0]);
        close(pipe3[1]);
        exit(0);
    }

    {
        close(pipe3[1]);
        double finalPrice;
        read(pipe3[0], &finalPrice, sizeof(finalPrice));

        double total;
        read(pipe1[0], &total, sizeof(total));
        vector<Item> items = {
            {"eggs", 3, 15.0}, 
            {"bread", 1, 60.0}, 
            {"chocolate", 5, 50.0}
        };

        sort(items.begin(), items.end(), [](const Item& a, const Item& b) {
            return a.quantity * a.price_per_item > b.quantity * b.price_per_item;
        });

        double taxedTotal = total + (total * 0.08);
        
        printReceipt(items, total, taxedTotal, finalPrice);
        
        close(pipe3[0]);
    }

    for (int i = 0; i < 4; ++i) {
        wait(NULL);
    }

    return 0;
}


