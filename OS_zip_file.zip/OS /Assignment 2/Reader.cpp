#include <iostream>
#include <string>
using namespace std;
int main() {
    string message;
    getline(cin, message); 
    cout << "Received message: " << message << endl;
    cout<<"How are you?"<<endl;
    return 0;
}
