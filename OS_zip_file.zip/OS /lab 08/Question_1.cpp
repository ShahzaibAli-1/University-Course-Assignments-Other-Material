#include <iostream>
#include <pthread.h>
#include <string>

using namespace std;

string x;

void* inputString(void* arg) 
{
    cout << "Enter a string: ";
    cin >> x; 
    return nullptr;
}


void* ascii(void* arg) 
{
    cout << "ASCII values: ";
    for (int i = 0; i < x.length(); i++) 
    {
        cout << int(x[i]) << " "; 
    }
    cout << endl;
    return nullptr;
}


void* reverse(void* arg) 
{
    cout << "Reverse: ";
    for (int i = x.length() - 1; i >= 0; i--) 
    {
        cout << x[i];
    }
    cout << endl;
    return nullptr;
}


void* checkPalindrome(void* arg) 
{
    for (int i = 0; i < x.length() / 2; i++) 
    {
        if (x[i] != x[x.length() - 1 - i]) 
        {
            cout << x << " is not a palindrome." << endl;
            return nullptr; 
        }
    }
    cout << x << " is a palindrome." << endl;
    return nullptr;
}

int main() 
{
    pthread_t t1, t2, t3, t4;
    

    pthread_create(&t1, nullptr, inputString, nullptr); 
    pthread_join(t1, nullptr); 


    pthread_create(&t2, nullptr, ascii, nullptr); 
    pthread_create(&t3, nullptr, reverse, nullptr); 
    pthread_create(&t4, nullptr, checkPalindrome, nullptr); 

    pthread_detach(t2);
    pthread_detach(t3);
    pthread_detach(t4);

    pthread_exit(nullptr);  

    return 0;
}