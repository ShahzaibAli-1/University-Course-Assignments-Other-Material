#include <iostream>
#include <pthread.h>
#include <unistd.h>
using namespace std;

#define ARRAY_SIZE 100
#define NUM_THREADS 4

int arr[ARRAY_SIZE];
int number_to_find;
bool found = false; 
pthread_t threads[NUM_THREADS]; 

void* search(void* arg) 
{
int * thread_id = (int *) (arg);
 
    int start, end;

if(*thread_id ==1){
                start = 0;
            end = 24;
}
else if(*thread_id==2){
                start = 25;
            end = 49;
}
else if(*thread_id==3){
            start = 50;
            end = 74;}
else if(*thread_id==4){
            start = 75;
            end = 99;
}
else{
    pthread_exit(nullptr);
}


    for (int i = start; i <= end; i++) 
    {
        if (arr[i] == number_to_find) 
        {
            found = true;
            cout << "Thread " << *thread_id << ": Found the number " << number_to_find << " at index " << i << endl;

            for (int j = 0; j < NUM_THREADS; j++) 
            {
                if (j != *thread_id - 1) 
                { 
                    pthread_cancel(threads[j]);
                }
            }
            pthread_exit(nullptr);
        }
    }
    pthread_exit(nullptr);
}

int main() {


    for (int i = 0; i < ARRAY_SIZE; i++) 
    {
        arr[i] = i + 1;
    }


    cout << "Enter a number to search (1-100): ";
    cin >> number_to_find;

    if (number_to_find < 1 || number_to_find > 100) 
    {
        cout << "Invalid number! Please enter a number between 1 and 100." << endl;
        return -1;
    }

    int thread_ids[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; i++) 
    {
        thread_ids[i] = i + 1; 
        pthread_create(&threads[i], nullptr, search, (void*)&thread_ids[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) 
    {
        pthread_join(threads[i], nullptr);
    }

    if (!found) {
        cout << "Number " << number_to_find << " not found in the array." << endl;
    }

    return 0;
}