#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <cstring>
#include<string.h>
using namespace std;

string inputString;


void *inputThread(void *arg) {
    cout << "Enter string: ";
    getline(cin, inputString);
    pthread_exit(NULL);
}


void *asciiThread(void *arg) {
    cout << "ASCII values: ";
    for (int i = 0; i < inputString.size(); i++) {
        cout << int(inputString[i])<<" ";  
    }
    cout << endl;
    pthread_exit(NULL);
}


void *reverseThread(void *arg) {
    cout << "Reverse string: ";
    for (int i = inputString.size() - 1; i >= 0; i--) {
        cout << inputString[i];  
    }
    cout << endl;
    pthread_exit(NULL);
}


void *palindromeThread(void *arg) {
    bool isPalindrome = true;
    int len =inputString.size();
    for (int i = 0; i < len / 2; i++) {
        if (inputString[i] != inputString[len - i - 1]) {
            isPalindrome = false;  
            break;
        }
    }
    if (isPalindrome) {
        cout << "Palindrome" << endl;
    } else {
        cout << "Not palindrome" << endl;
    }
    pthread_exit(NULL);
}

int main() {

    pthread_t input_tid, ascii_tid, reverse_tid, palindrome_tid;
    pthread_create(&input_tid, NULL, inputThread, NULL);
    pthread_join(input_tid, NULL);
    pthread_create(&ascii_tid, NULL, asciiThread, NULL);
    pthread_create(&reverse_tid, NULL, reverseThread, NULL);
    pthread_create(&palindrome_tid, NULL, palindromeThread, NULL);
    pthread_join(ascii_tid, NULL);
    pthread_join(reverse_tid, NULL);
    pthread_join(palindrome_tid, NULL);

    return 0;
}
