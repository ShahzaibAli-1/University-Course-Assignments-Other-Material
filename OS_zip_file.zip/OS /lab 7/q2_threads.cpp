#include <iostream>
#include <pthread.h>
#include <cstdlib> 
#include <ctime>   
using namespace std;

const int SIZE = 1000;
const int SUB_SIZE = 250;

int matrixA[SIZE][SIZE];
int matrixB[SIZE][SIZE];
int result[SIZE][SIZE];


struct ThreadData {
    int startRow;
    int endRow;
};


void initializeMatrix(int matrix[SIZE][SIZE]) {
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            matrix[i][j] = rand() % 100;  
        }
    }
}


void *multiplySubMatrix(void *arg) {
    ThreadData *data = (ThreadData *)arg;
    int start = data->startRow;
    int end = data->endRow;


    for (int i = start; i < end; i++) {
        for (int j = 0; j < SIZE; j++) {
            result[i][j] = 0;
            for (int k = 0; k < SIZE; k++) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }
    pthread_exit(NULL);
}

int main() {

    srand(time(0));


    initializeMatrix(matrixA);
    initializeMatrix(matrixB);


    pthread_t threads[4];

    ThreadData threadData[4];


    for (int i = 0; i < 4; i++) {
        threadData[i].startRow = i * SUB_SIZE;
        threadData[i].endRow = (i + 1) * SUB_SIZE;
        pthread_create(&threads[i], NULL, multiplySubMatrix, (void *)&threadData[i]);
    }


    for (int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }


    cout << "result matrix (10x10 top-left corner):" << endl;
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            cout << result[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}
