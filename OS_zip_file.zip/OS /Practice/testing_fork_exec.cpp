#include<iostream>
#include<unistd.h>
#include<stdlib.h>

using namespace std;


int main(){
// fork();    
    // int n;
    // cout<<"\n";
    // cin>>n;

    // for(int i = 0 ;i<n;i++){
    //     for(int j = 0 ;j<=i;j++){
    //         cout<<"*";
    //     }
    //     cout<<"\n";
    // }
    // cout<<"\n";
    // cout<<getppid()<<"\n";
    cout<<"Time is 2\n ";
    if(fork() && (!fork())){

        if(fork()||fork()){
            fork();
        }
    }
    cout<<"1"<<endl;
    

    return 0 ;
}