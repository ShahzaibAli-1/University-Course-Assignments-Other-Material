#include <iostream>
#include <pthread.h>
#include <unistd.h>

using namespace std;

int total_amount = 100;  
pthread_mutex_t mutex_balance;


void* withdraw(void* args) {
    int tid = *((int*)args);
    for (int i = 0; i < 10; i++) {
        pthread_mutex_lock(&mutex_balance);  

        if (total_amount >= 10) {
            cout << "At time " << i << ", balance before withdrawal by thread " << tid << " is $" << total_amount << endl;
            total_amount -= 10;
            cout << "At time " << i << ", balance after withdrawal by thread " << tid << " is $" << total_amount << endl;
        } else {
            cout << "At time " << i << ", insufficient funds for withdrawal by thread " << tid << ". Current balance: $" << total_amount << endl;
        }

        pthread_mutex_unlock(&mutex_balance);  
        sleep(1);  
    }
    return NULL;
}


void* deposit(void* args) {
    int tid = *((int*)args);
    for (int i = 0; i < 10; i++) {
        pthread_mutex_lock(&mutex_balance);  


        cout << "At time " << i << ", balance before deposit by thread " << tid << " is $" << total_amount << endl;
        total_amount += 11;
        cout << "At time " << i << ", balance after deposit by thread " << tid << " is $" << total_amount << endl;

        pthread_mutex_unlock(&mutex_balance);  
        sleep(1);  
    }
    return NULL;
}

int main() {

    pthread_mutex_init(&mutex_balance, NULL);


    pthread_t t1, t2, t3, t4;
    int id1 = 1, id2 = 2, id3 = 3, id4 = 4;


    pthread_create(&t1, NULL, withdraw, &id1);

    pthread_create(&t3, NULL, deposit, &id3);
    pthread_create(&t4, NULL, deposit, &id4);
    pthread_create(&t2, NULL, withdraw, &id2);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);


    pthread_mutex_destroy(&mutex_balance);

    cout << "Final balance: $" << total_amount << endl;
    return 0;
}
