#include <iostream>
#include <pthread.h>
#include <unistd.h>

using namespace std;


int total_amount = 100;  
pthread_mutex_t mutex_balance;
pthread_cond_t cond_balance;


void* withdraw(void* args) {
    int tid = *((int*)args);
    for (int i = 0; i < 10; i++) {
        pthread_mutex_lock(&mutex_balance);  


        while (total_amount < 10) {
            pthread_cond_wait(&cond_balance, &mutex_balance);
        }


        cout << "At time " << i << ", balance before withdrawal by thread " << tid << " is $" << total_amount << endl;
        total_amount -= 10;
        cout << "At time " << i << ", balance after withdrawal by thread " << tid << " is $" << total_amount << endl;

        pthread_mutex_unlock(&mutex_balance);  
        pthread_cond_signal(&cond_balance);    
        sleep(1);                              
    }
    return nullptr;
}


void* deposit(void* args) {
    int tid = *((int*)args);
    for (int i = 0; i < 10; i++) {
        pthread_mutex_lock(&mutex_balance);  


        cout << "At time " << i << ", balance before deposit by thread " << tid << " is $" << total_amount << endl;
        total_amount += 11;
        cout << "At time " << i << ", balance after deposit by thread " << tid << " is $" << total_amount << endl;

        pthread_mutex_unlock(&mutex_balance);
        pthread_cond_signal(&cond_balance);    
        sleep(1);                              
    }
    return nullptr;
}

int main() {

    pthread_mutex_init(&mutex_balance, nullptr);
    pthread_cond_init(&cond_balance, nullptr);


    pthread_t t1, t2, t3, t4;
    int id1 = 1, id2 = 2, id3 = 3, id4 = 4;


    pthread_create(&t1, nullptr, withdraw, &id1);
    pthread_create(&t2, nullptr, withdraw, &id2);
    pthread_create(&t3, nullptr, deposit, &id3);
    pthread_create(&t4, nullptr, deposit, &id4);


    pthread_join(t1, nullptr);
    pthread_join(t2, nullptr);
    pthread_join(t3, nullptr);
    pthread_join(t4, nullptr);


    pthread_mutex_destroy(&mutex_balance);
    pthread_cond_destroy(&cond_balance);

    cout << "Final balance: $" << total_amount << endl;
    return 0;
}
