#include<iostream>
#include<thread>
using namespace std;
int arr[100];
void fill_array(){
for(int i=  0 ;i<100;i++){
    arr[i] = i+1;
}

}

void print_array(){
    for(int i= 0 ; i<100;i++){
        cout<<arr[i]<<" ";
    }
}
int main(){

    thread t1(fill_array);
    t1.join();
    thread t2(print_array);
    t2.join();
    return 0 ;
}