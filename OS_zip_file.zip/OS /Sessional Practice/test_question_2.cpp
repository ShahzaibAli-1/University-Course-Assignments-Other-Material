#include<iostream>
#include<string>
#include<thread>
using namespace std;

string name;
void input(){
cout<<"Enter the string: ";
cin>>name;


}
void reverse(){
    for(int i= name.length() -1  ; i>-1;i++){

        cout<<name[i];
    }
    cout<<"\n";
}
void assci_thread(){
    for(int i= 0 ; i<name.length() -1 ;i++){
        cout<<int(name[i])<<" ";
    }
    cout<<"\n";
}
void palindrome_thread(){
    for(int i = 0;i<name.length()/2;i++){

        if(name[i]!=name[name.length() - i]){
            cout<<"Not palindrome\n";
            return;
        }
    }
    cout<<"Palindrome\n";
    
}

int main(){

thread t1(input);
t1.join();
thread t2(reverse);
t2.join();
thread t3(assci_thread);
t3.join();
thread t4 (palindrome_thread);
t4.join();


    return 0;
}