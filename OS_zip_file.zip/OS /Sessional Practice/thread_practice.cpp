// #include<iostream>
// #include<pthread.h>
// using namespace std;
// void *thread_value(void * args){
// int *value = (int* )args;
// cout<<*value<<" ";
// pthread_exit(NULL);
// }
// int main(){
// pthread_t p1;
// int test_value;
// cin>>test_value;
// pthread_create(&p1, NULL, thread_value, (void *)&test_value);
// pthread_exit(NULL);

//     return 0;
// }
#include<iostream>
#include<unistd.h>
#include<pthread.h>
#include<cstring>
#include<string.h>
using namespace std;


int main(){
int p1[2], p2[2];
if(pipe(p1)==-1 or pipe(p2) == -1){
    cout<<"Pipe creation failed\n";
    return -1;
}
pid_t pid = fork();
if(pid>0){
close(p1[0]);
close(p1[1]);
char arr[20];
while(true){
    cin>>arr;
    write(p1[1], arr, strlen(arr+1));
}
}

else{


}

    return 0;
}