#include <iostream>
#include <vector>
#include <thread>
#include <queue>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <condition_variable>

const int BOARD_SIZE = 10; // Replace this with the calculated size based on roll number
std::mutex coutMutex; // Mutex for synchronized output

class GameBoard {
public:
    GameBoard(int size) : size(size), board(size, std::vector<char>(size, ' ')) {}

    void placeItems(int numItems) {
        for (int i = 0; i < numItems; ++i) {
            int x = rand() % size;
            int y = rand() % size;
            board[x][y] = '*'; // Item on the board
            items.emplace_back(x, y);
        }
    }

    void display() {
        std::lock_guard<std::mutex> lock(coutMutex);
        for (const auto& row : board) {
            for (char cell : row) std::cout << cell << " ";
            std::cout << std::endl;
        }
        std::cout << std::endl;
    }

    bool collectItem(int x, int y) {
        std::lock_guard<std::mutex> lock(boardMutex);
        if (board[x][y] == '*') {
            board[x][y] = ' ';
            return true;
        }
        return false;
    }

    void updatePosition(int oldX, int oldY, int newX, int newY, char symbol) {
        std::lock_guard<std::mutex> lock(boardMutex);
        board[oldX][oldY] = ' ';
        board[newX][newY] = symbol;
    }

    int getSize() const { return size; }

private:
    int size;
    std::vector<std::vector<char>> board;
    std::vector<std::pair<int, int>> items;
    std::mutex boardMutex; // Mutex to protect board modifications
};

class Player {
public:
    Player(int id, GameBoard& gameBoard, std::queue<std::string>& msgQueue)
        : playerId(id), board(gameBoard), messageQueue(msgQueue), score(0) {}

    void operator()() {
        int x = rand() % board.getSize();
        int y = rand() % board.getSize();
        board.updatePosition(x, y, x, y, 'A' + playerId); // Initial position
        while (true) {
            int direction = rand() % 4; // Random direction
            int newX = x, newY = y;
            move(direction, newX, newY);

            // Check if within bounds
            if (newX >= 0 && newX < board.getSize() && newY >= 0 && newY < board.getSize()) {
                if (board.collectItem(newX, newY)) {
                    score++;
                    sendMessage("Player " + std::to_string(playerId) + " collected an item!");
                }
                board.updatePosition(x, y, newX, newY, 'A' + playerId);
                x = newX;
                y = newY;

                std::this_thread::sleep_for(std::chrono::milliseconds(500)); // Delay to simulate turn-based movement
            }
        }
    }

    int getScore() const { return score; }

private:
    int playerId;
    GameBoard& board;
    std::queue<std::string>& messageQueue;
    int score;

    void move(int direction, int& x, int& y) {
        switch (direction) {
            case 0: x--; break; // Up
            case 1: x++; break; // Down
            case 2: y--; break; // Left
            case 3: y++; break; // Right
        }
    }

    void sendMessage(const std::string& message) {
        std::lock_guard<std::mutex> lock(coutMutex);
        messageQueue.push(message);
    }
};


int main() {
    srand(time(0)); // Seed for random numbers
    GameBoard gameBoard(BOARD_SIZE);
    gameBoard.placeItems(10); // Place 10 random items on the board

    std::queue<std::string> messageQueue;

    // Create player threads
    Player player1(0, gameBoard, messageQueue);
    Player player2(1, gameBoard, messageQueue);

    std::thread player1Thread(std::ref(player1));
    std::thread player2Thread(std::ref(player2));

    // Main game loop to display board and process messages
    while (true) {
        gameBoard.display();
        if (!messageQueue.empty()) {
            std::lock_guard<std::mutex> lock(coutMutex);
            while (!messageQueue.empty()) {
                std::cout << messageQueue.front() << std::endl;
                messageQueue.pop();
            }
        }
        std::this_thread::sleep_for(std::chrono::seconds(1)); // Refresh rate
    }

    // Join threads
    player1Thread.join();
    player2Thread.join();

    return 0;
}
