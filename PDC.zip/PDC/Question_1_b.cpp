#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h> 

#define MATRIX_SIZE 1024
#define NUM_THREADS 6

double matrix[MATRIX_SIZE][MATRIX_SIZE];
double transposed[MATRIX_SIZE][MATRIX_SIZE];
double sequential_transposed[MATRIX_SIZE][MATRIX_SIZE]; 

typedef struct {
    int thread_id;
} ThreadData;

//function for multi-threaded transposition
void* transpose_rows(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    for (int i = data->thread_id; i < MATRIX_SIZE; i += NUM_THREADS) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            transposed[j][i] = matrix[i][j];
        }
    }
    pthread_exit(NULL);
}

//function for sequential transposition
void sequential_transpose() {
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            sequential_transposed[j][i] = matrix[i][j];
        }
    }
}

//function to verify correctness of transposition
bool CorrectOutputCheck() {
    sequential_transpose();
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            if (transposed[i][j] != sequential_transposed[i][j]) {
                return false; 
            }
        }
    }
    return true; 
}

//function to print a small sample of a matrix
void printMatrixSample(double mat[MATRIX_SIZE][MATRIX_SIZE], int rows, int cols, const char* title) {
    printf("%s (Top-Left %dx%d):\n", title, rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%5.2f ", mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    pthread_t threads[NUM_THREADS];
    ThreadData thread_data[NUM_THREADS];

    //initializing matrix with random values (between 0 and 1)
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX;
        }
    }

    //printing a small portion of the original matrix
    printMatrixSample(matrix, 10, 10, "Original Matrix");

    //creating threads for row-wise cyclic distribution
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_data[i].thread_id = i;
        pthread_create(&threads[i], NULL, transpose_rows, (void*)&thread_data[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    //printing a small portion of the transposed matrix
    printMatrixSample(transposed, 10, 10, "Transposed Matrix");

    //verifying correctness
    if (CorrectOutputCheck()) {
        printf("Transposition is correct.\n");
    } else {
        printf("Transposition is incorrect.\n");
    }

    return 0;
}
