#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <stdbool.h> 

#define MATRIX_SIZE 1024
#define NUM_THREADS 6

double matrix[MATRIX_SIZE][MATRIX_SIZE];
double transposed[MATRIX_SIZE][MATRIX_SIZE];
double sequential_transposed[MATRIX_SIZE][MATRIX_SIZE]; 

typedef struct {
    int thread_id;
} ThreadData;

//function for multithreaded transpostion
void* transpose_rows(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    for (int i = data->thread_id; i < MATRIX_SIZE; i += NUM_THREADS) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            transposed[j][i] = matrix[i][j];
        }
    }
    pthread_exit(NULL);
}

//function for sequential transposition
void sequential_transpose() {
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            sequential_transposed[j][i] = matrix[i][j];
        }
    }
}

//function to verifying correctness of transposition
bool CorrectOutputCheck() {

    sequential_transpose();

    // Compare multi-threaded result with sequential result
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            if (transposed[i][j] != sequential_transposed[i][j]) {
                return false; 
            }
        }
    }
    return true; 
}

int main() {
    pthread_t threads[NUM_THREADS];
    ThreadData thread_data[NUM_THREADS];

    //initialize matrix with random values
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX;
        }
    }

    //creating threads for row wise cyclic distribution
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_data[i].thread_id = i;
        pthread_create(&threads[i], NULL, transpose_rows, (void*)&thread_data[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    // verifying correctness
    if (CorrectOutputCheck()) {
        printf("Transposition is correct.\n");
    } else {
        printf("Transposition is incorrect.\n");
    }

    return 0;
}