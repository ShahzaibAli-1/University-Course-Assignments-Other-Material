#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <stdbool.h> 

#define MATRIX_SIZE 1024
#define NUM_THREADS 6
#define TOLERANCE 1e-9 

double matrix[MATRIX_SIZE][MATRIX_SIZE];
double log_matrix[MATRIX_SIZE][MATRIX_SIZE];
double sequential_log_matrix[MATRIX_SIZE][MATRIX_SIZE]; 

typedef struct {
    int thread_id;
} ThreadData;

//function for log transformaton
void* compute_logarithm(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    for (int i = data->thread_id; i < MATRIX_SIZE; i += NUM_THREADS) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            log_matrix[i][j] = log(matrix[i][j]);
        }
    }
    pthread_exit(NULL);
}

//function for sequential log transformation
void sequential_logarithm() {
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            sequential_log_matrix[i][j] = log(matrix[i][j]);
        }
    }
}

//function for verifying correctness 
bool CorrectOutputCheck() {

    sequential_logarithm();


    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            if (fabs(log_matrix[i][j] - sequential_log_matrix[i][j]) > TOLERANCE) {
                return false; 
            }
        }
    }
    return true; 
}

int main() {
    pthread_t threads[NUM_THREADS];
    ThreadData thread_data[NUM_THREADS];

    //initialize matrix with random values
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX + 1;
        }
    }


    for (int i = 0; i < NUM_THREADS; i++) {
        thread_data[i].thread_id = i;
        pthread_create(&threads[i], NULL, compute_logarithm, (void*)&thread_data[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    if (CorrectOutputCheck()) {
        printf("Logarithm transformation is correct.\n");
    } else {
        printf("Logarithm transformation is incorrect.\n");
    }

    return 0;
}