#include <iostream>
#include <vector>
#include <omp.h>
using namespace std;

const int N = 100;
const int GENERATIONS = 100;
vector<vector<char>> grid(N, vector<char>(N, '.'));
vector<vector<char>> newGrid(N, vector<char>(N, '.'));


void printGrid() {
    for (const auto& row : grid) {
        for (char cell : row) {
            cout << cell;
        }
        cout << endl;
    }
    cout << "----------------------" << endl;
}

void initializeGrid() {
    for (int i = 45; i < 55; i++)
        for (int j = 45; j < 55; j++)
            grid[i][j] = '*';
}

int countLiveNeighbors(int x, int y) {
    int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1};
    int dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};
    int count = 0;

    for (int i = 0; i < 8; i++) {
        int nx = (x + dx[i] + N) % N;
        int ny = (y + dy[i] + N) % N;
        if (grid[nx][ny] == '*')
            count++;
    }
    return count;
}

void updateGridSerial() {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int liveNeighbors = countLiveNeighbors(i, j);
            if (grid[i][j] == '*' && (liveNeighbors < 2 || liveNeighbors > 3))
                newGrid[i][j] = '.';
            else if (grid[i][j] == '.' && liveNeighbors == 3)
                newGrid[i][j] = '*';
            else
                newGrid[i][j] = grid[i][j];
        }
    }
    grid = newGrid;
    printGrid();
}

void updateGridParallelStatic() {
    #pragma omp parallel for schedule(static, 1)
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int liveNeighbors = countLiveNeighbors(i, j);
            if (grid[i][j] == '*' && (liveNeighbors < 2 || liveNeighbors > 3))
                newGrid[i][j] = '.';
            else if (grid[i][j] == '.' && liveNeighbors == 3)
                newGrid[i][j] = '*';
            else
                newGrid[i][j] = grid[i][j];
        }
    }
    grid = newGrid;
    printGrid();
}

void updateGridParallelGuided() {
    #pragma omp parallel for schedule(guided, 1)
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            int liveNeighbors = countLiveNeighbors(i, j);
            if (grid[i][j] == '*' && (liveNeighbors < 2 || liveNeighbors > 3))
                newGrid[i][j] = '.';
            else if (grid[i][j] == '.' && liveNeighbors == 3)
                newGrid[i][j] = '*';
            else
                newGrid[i][j] = grid[i][j];
        }
    }
    grid = newGrid;
    printGrid();
}



void measureExecutionTime(void (*updateFunc)(), const string& method) {
    double totalTime = 0;
    for (int i = 0; i < 5; i++) {
        initializeGrid();
        double start = omp_get_wtime();
        for (int gen = 0; gen < GENERATIONS; gen++) {
            updateFunc();
        }
        double end = omp_get_wtime();
        totalTime += (end - start);
    }
    cout << method << " Average Time: " << (totalTime / 5) << " seconds\n";
}

int main() {
    initializeGrid();

    // Measure execution times
    measureExecutionTime(updateGridSerial, "Serial");
    measureExecutionTime(updateGridParallelStatic, "Parallel (Static)");
    measureExecutionTime(updateGridParallelGuided, "Parallel (Guided)");

    return 0;
}
