#include <iostream>
#include <vector>
#include <pthread.h>
#include <random>
#include <unistd.h>
#include <atomic>
#include <algorithm>
#include <iomanip>
#include <omp.h>
#include <cstring>
#include <cstdlib>

// Structure for grid cell
struct Cell {
    enum Type { EMPTY, TREASURE, TRAP, DEADLY_TRAP, RESURRECTION_STONE, BARRIER };
    Type type;
    int value;  // Score for treasure or penalty for trap
    bool visited;
    
    Cell() : type(EMPTY), value(0), visited(false) {}
};

// Structure for adventurer
struct Adventurer {
    int id;
    int x, y;       // Current position
    int score;
    bool active;    // Whether the adventurer is still in the game
    std::vector<std::pair<int, int>> visitedCells;
    
    Adventurer(int _id, int _x, int _y) : id(_id), x(_x), y(_y), score(0), active(true) {}
    
    bool hasVisited(int _x, int _y) {
        return std::find(visitedCells.begin(), visitedCells.end(), std::make_pair(_x, _y)) != visitedCells.end();
    }
    
    void markVisited(int _x, int _y) {
        visitedCells.push_back(std::make_pair(_x, _y));
    }
};

// Global variables
int gridSize;                   // Size of the grid (N)
int numThreads;                 // Initial number of threads (T)
std::vector<std::vector<Cell>> grid;  // The grid
std::vector<Adventurer> adventurers;  // List of all adventurers
pthread_mutex_t gridMutex;      // Mutex for accessing the grid
pthread_mutex_t adventurersMutex; // Mutex for accessing the adventurers list
pthread_mutex_t printMutex;     // Mutex for controlling print operations
pthread_cond_t barrierCV;       // Condition variable for barrier synchronization
pthread_mutex_t barrierMutex;   // Mutex for barrier synchronization
int barrierCount = 0;           // Counter for barrier synchronization
int barrierThreshold;           // Number of adventurers needed to pass barrier
bool gameOver = false;          // Flag to indicate game over
int treasuresRemaining = 0;     // Counter for remaining treasures
int highestScore = 0;           // Highest score achieved so far
int winnerID = -1;              // ID of the adventurer with the highest score
std::atomic<int> activeAdventurers(0);  // Counter for active adventurers
int moveCounter = 0;            // Counter for moves (for synchronization)
const int CHECKPOINT_INTERVAL = 5;  // Synchronize after every 5 moves

// Function prototypes
void initializeGrid();
void printGrid();
void printAdventurers();
void* adventurerThread(void* arg);
bool makeMove(Adventurer& adv);
void synchronizeAtCheckpoint();
void spawnNewAdventurer(int x, int y);
void checkGameOver();

// Random number generator
std::random_device rd;
std::mt19937 gen(rd());

int main(int argc, char* argv[]) {
    // Parse command-line arguments
    if (argc != 3) {
        std::cout << "Usage: " << argv[0] << " <grid_size> <num_threads>" << std::endl;
        return 1;
    }
    
    gridSize = std::stoi(argv[1]);
    numThreads = std::stoi(argv[2]);
    
    // Initialize mutexes and condition variables
    pthread_mutex_init(&gridMutex, NULL);
    pthread_mutex_init(&adventurersMutex, NULL);
    pthread_mutex_init(&printMutex, NULL);
    pthread_mutex_init(&barrierMutex, NULL);
    pthread_cond_init(&barrierCV, NULL);
    
    // Initialize the grid
    initializeGrid();
    
    // Initialize adventurers
    adventurers.reserve(numThreads * 2);  // Reserve space for potential new adventurers
    
    // Use OpenMP to parallelize adventurer initialization
    #pragma omp parallel
    {
        std::random_device localRd;
        std::mt19937 localGen(localRd());
        std::uniform_int_distribution<> posDist(0, gridSize - 1);
        
        #pragma omp for
        for (int i = 0; i < numThreads; ++i) {
            int x, y;
            
            #pragma omp critical
            {
                x = posDist(localGen);
                y = posDist(localGen);
                
                pthread_mutex_lock(&adventurersMutex);
                adventurers.emplace_back(i, x, y);
                adventurers[i].markVisited(x, y);
                activeAdventurers++;
                pthread_mutex_unlock(&adventurersMutex);
            }
        }
    }
    
    // Set barrier threshold (half of initial adventurers)
    barrierThreshold = numThreads / 2;
    
    // Print initial state
    pthread_mutex_lock(&printMutex);
    std::cout << "=== Initial Grid ===" << std::endl;
    printGrid();
    std::cout << "=== Initial Adventurers ===" << std::endl;
    printAdventurers();
    pthread_mutex_unlock(&printMutex);
    
    // Create threads for adventurers
    pthread_t threads[numThreads];
    int thread_args[numThreads];
    
    for (int i = 0; i < numThreads; ++i) {
        thread_args[i] = i;
        pthread_create(&threads[i], NULL, adventurerThread, &thread_args[i]);
    }
    
    // Wait for all threads to finish
    for (int i = 0; i < numThreads; ++i) {
        pthread_join(threads[i], NULL);
    }
    
    // Print final results
    pthread_mutex_lock(&printMutex);
    std::cout << "=== Game Over ===" << std::endl;
    std::cout << "Winner: Adventurer " << winnerID << " with score " << highestScore << std::endl;
    std::cout << "=== Final Grid State ===" << std::endl;
    printGrid();
    std::cout << "=== Final Adventurers State ===" << std::endl;
    printAdventurers();
    pthread_mutex_unlock(&printMutex);
    
    // Cleanup
    pthread_mutex_destroy(&gridMutex);
    pthread_mutex_destroy(&adventurersMutex);
    pthread_mutex_destroy(&printMutex);
    pthread_mutex_destroy(&barrierMutex);
    pthread_cond_destroy(&barrierCV);
    
    return 0;
}

// Initialize the grid with random treasures, traps, etc.
void initializeGrid() {
    grid.resize(gridSize, std::vector<Cell>(gridSize));
    
    // Use OpenMP to parallelize grid initialization
    #pragma omp parallel
    {
        std::random_device localRd;
        std::mt19937 localGen(localRd());
        std::uniform_int_distribution<> typeDist(0, 100);
        std::uniform_int_distribution<> treasureValueDist(10, 50);
        std::uniform_int_distribution<> trapValueDist(5, 25);
        
        #pragma omp for collapse(2) reduction(+:treasuresRemaining)
        for (int i = 0; i < gridSize; ++i) {
            for (int j = 0; j < gridSize; ++j) {
                int type = typeDist(localGen);
                
                if (type < 30) {  // 30% chance of treasure
                    grid[i][j].type = Cell::TREASURE;
                    grid[i][j].value = treasureValueDist(localGen);
                    treasuresRemaining++;
                } else if (type < 50) {  // 20% chance of trap
                    grid[i][j].type = Cell::TRAP;
                    grid[i][j].value = trapValueDist(localGen);
                } else if (type < 55) {  // 5% chance of deadly trap
                    grid[i][j].type = Cell::DEADLY_TRAP;
                    grid[i][j].value = trapValueDist(localGen) * 2;
                } else if (type < 58) {  // 3% chance of resurrection stone
                    grid[i][j].type = Cell::RESURRECTION_STONE;
                    grid[i][j].value = 0;
                } else if (type < 63) {  // 5% chance of barrier
                    grid[i][j].type = Cell::BARRIER;
                    grid[i][j].value = treasureValueDist(localGen);
                } else {  // 37% chance of empty
                    grid[i][j].type = Cell::EMPTY;
                    grid[i][j].value = 0;
                }
            }
        }
    }
}

// Print the current state of the grid
void printGrid() {
    pthread_mutex_lock(&gridMutex);
    
    std::cout << "  ";
    for (int j = 0; j < gridSize; ++j) {
        std::cout << std::setw(3) << j;
    }
    std::cout << std::endl;
    
    for (int i = 0; i < gridSize; ++i) {
        std::cout << std::setw(2) << i;
        for (int j = 0; j < gridSize; ++j) {
            char symbol;
            switch (grid[i][j].type) {
                case Cell::EMPTY: symbol = '.'; break;
                case Cell::TREASURE: symbol = 'T'; break;
                case Cell::TRAP: symbol = 'X'; break;
                case Cell::DEADLY_TRAP: symbol = 'D'; break;
                case Cell::RESURRECTION_STONE: symbol = 'R'; break;
                case Cell::BARRIER: symbol = 'B'; break;
                default: symbol = '?'; break;
            }
            std::cout << " " << symbol << (grid[i][j].visited ? "*" : " ");
        }
        std::cout << std::endl;
    }
    
    pthread_mutex_unlock(&gridMutex);
}

// Print the current state of all adventurers
void printAdventurers() {
    pthread_mutex_lock(&adventurersMutex);
    
    std::cout << "ID\tPosition\tScore\tActive" << std::endl;
    for (const auto& adv : adventurers) {
        std::cout << adv.id << "\t(" << adv.x << ", " << adv.y << ")\t"
                  << adv.score << "\t" << (adv.active ? "Yes" : "No") << std::endl;
    }
    
    pthread_mutex_unlock(&adventurersMutex);
}

// Thread function for each adventurer
void* adventurerThread(void* arg) {
    int id = *((int*)arg);
    
    while (!gameOver) {
        // Check if this adventurer is still active
        pthread_mutex_lock(&adventurersMutex);
        bool isActive = adventurers[id].active;
        pthread_mutex_unlock(&adventurersMutex);
        
        if (!isActive) {
            break;
        }
        
        // Make a move
        bool madeMoveSuccessfully = makeMove(adventurers[id]);
        
        // If couldn't make a move (all cells visited or stuck), terminate this adventurer
        if (!madeMoveSuccessfully) {
            pthread_mutex_lock(&adventurersMutex);
            adventurers[id].active = false;
            activeAdventurers--;
            pthread_mutex_unlock(&adventurersMutex);
            
            pthread_mutex_lock(&printMutex);
            std::cout << "Adventurer " << id << " is stuck and terminates." << std::endl;
            pthread_mutex_unlock(&printMutex);
            break;
        }
        
        // Synchronize at checkpoints
        pthread_mutex_lock(&adventurersMutex);
        moveCounter++;
        bool shouldSync = (moveCounter % CHECKPOINT_INTERVAL == 0);
        pthread_mutex_unlock(&adventurersMutex);
        
        if (shouldSync) {
            synchronizeAtCheckpoint();
        }
        
        // Check if game is over
        checkGameOver();
        
        // Sleep for a short time to make the simulation visible
        usleep(100000);  // 100ms
    }
    
    return NULL;
}

// Make a move for an adventurer
bool makeMove(Adventurer& adv) {
    std::uniform_int_distribution<> dirDist(0, 3);  // 0: up, 1: right, 2: down, 3: left
    
    // Try all directions in a random order
    std::vector<int> directions = {0, 1, 2, 3};
    std::shuffle(directions.begin(), directions.end(), gen);
    
    for (int dir : directions) {
        int newX = adv.x;
        int newY = adv.y;
        
        switch (dir) {
            case 0: newX--; break;  // Up
            case 1: newY++; break;  // Right
            case 2: newX++; break;  // Down
            case 3: newY--; break;  // Left
        }
        
        // Check if the new position is valid
        if (newX < 0 || newX >= gridSize || newY < 0 || newY >= gridSize) {
            continue;  // Out of bounds
        }
        
        // Check if the cell has been visited by this adventurer
        pthread_mutex_lock(&adventurersMutex);
        bool hasVisited = adv.hasVisited(newX, newY);
        pthread_mutex_unlock(&adventurersMutex);
        
        if (hasVisited) {
            continue;
        }
        
        // Lock the grid for modification
        pthread_mutex_lock(&gridMutex);
        pthread_mutex_lock(&adventurersMutex);
        
        // Process the cell based on its type
        Cell& cell = grid[newX][newY];
        
        // Handle barrier
        if (cell.type == Cell::BARRIER && adv.score < cell.value) {
            pthread_mutex_unlock(&adventurersMutex);
            pthread_mutex_unlock(&gridMutex);
            
            pthread_mutex_lock(&printMutex);
            std::cout << "Adventurer " << adv.id << " cannot pass barrier at (" 
                      << newX << ", " << newY << ") - score too low." << std::endl;
            pthread_mutex_unlock(&printMutex);
            
            continue;  // Cannot pass the barrier
        }
        
        // Move to the new position
        int oldX = adv.x;
        int oldY = adv.y;
        adv.x = newX;
        adv.y = newY;
        adv.markVisited(newX, newY);
        cell.visited = true;
        
        // Process cell effects
        int statusChange = 0;  // 0: normal, 1: found resurrection stone, 2: hit deadly trap
        int scoreChange = 0;
        int cellType = cell.type;
        int cellValue = cell.value;
        
        switch (cell.type) {
            case Cell::TREASURE:
                adv.score += cell.value;
                scoreChange = cell.value;
                treasuresRemaining--;
                // Change cell to empty after treasure is collected
                cell.type = Cell::EMPTY;
                cell.value = 0;
                break;
                
            case Cell::TRAP:
                adv.score -= cell.value;
                scoreChange = -cell.value;
                break;
                
            case Cell::DEADLY_TRAP:
                adv.score -= cell.value;
                scoreChange = -cell.value;
                adv.active = false;
                activeAdventurers--;
                statusChange = 2;  // Hit deadly trap
                break;
                
            case Cell::RESURRECTION_STONE:
                statusChange = 1;  // Found resurrection stone
                // Change cell to empty after stone is used
                cell.type = Cell::EMPTY;
                cell.value = 0;
                break;
                
            case Cell::BARRIER:
                // Already handled above
                break;
                
            default:
                // Empty cell, no special effect
                break;
        }
        
        // Update highest score
        if (adv.score > highestScore) {
            highestScore = adv.score;
            winnerID = adv.id;
        }
        
        // Save ID for printing
        int advID = adv.id;
        int advScore = adv.score;
        
        pthread_mutex_unlock(&adventurersMutex);
        pthread_mutex_unlock(&gridMutex);
        
        // Print move results
        pthread_mutex_lock(&printMutex);
        switch (cellType) {
            case Cell::TREASURE:
                std::cout << "Adventurer " << advID << " found treasure worth " 
                          << cellValue << " points at (" << newX << ", " << newY << ")." << std::endl;
                break;
                
            case Cell::TRAP:
                std::cout << "Adventurer " << advID << " hit a trap losing " 
                          << cellValue << " points at (" << newX << ", " << newY << ")." << std::endl;
                break;
                
            case Cell::DEADLY_TRAP:
                std::cout << "Adventurer " << advID << " hit a DEADLY trap losing " 
                          << cellValue << " points and is terminated at (" 
                          << newX << ", " << newY << ")." << std::endl;
                break;
                
            case Cell::RESURRECTION_STONE:
                std::cout << "Adventurer " << advID << " found a Resurrection Stone at (" 
                          << newX << ", " << newY << ")." << std::endl;
                break;
                
            case Cell::BARRIER:
                std::cout << "Adventurer " << advID << " passed a barrier at (" 
                          << newX << ", " << newY << ")." << std::endl;
                break;
                
            default:
                std::cout << "Adventurer " << advID << " moved to empty cell (" 
                          << newX << ", " << newY << ")." << std::endl;
                break;
        }
        
        if (advScore > highestScore - scoreChange) {
            std::cout << "Adventurer " << advID << " now has the highest score: " 
                      << advScore << std::endl;
        }
        pthread_mutex_unlock(&printMutex);
        
        // Handle special status changes
        if (statusChange == 1) {
            // Spawn a new adventurer
            spawnNewAdventurer(newX, newY);
        } else if (statusChange == 2) {
            // Adventurer hit deadly trap and is terminated
            return false;
        }
        
        return true;  // Successfully made a move
    }
    
    return false;  // Could not make a move (all directions invalid)
}

// Synchronize all threads at a checkpoint
void synchronizeAtCheckpoint() {
    pthread_mutex_lock(&barrierMutex);
    
    // Increment barrier count
    barrierCount++;
    
    pthread_mutex_lock(&printMutex);
    std::cout << "Checkpoint reached. Barrier count: " << barrierCount 
              << "/" << barrierThreshold << std::endl;
    pthread_mutex_unlock(&printMutex);
    
    // If enough adventurers have reached the barrier, release all
    if (barrierCount >= barrierThreshold) {
        pthread_mutex_lock(&printMutex);
        std::cout << "Barrier threshold reached. All adventurers can proceed." << std::endl;
        pthread_mutex_unlock(&printMutex);
        
        barrierCount = 0;  // Reset the counter
        pthread_cond_broadcast(&barrierCV);  // Notify all waiting threads
    } else {
        // Wait for more adventurers to reach the barrier
        pthread_cond_wait(&barrierCV, &barrierMutex);
    }
    
    pthread_mutex_unlock(&barrierMutex);
    
    // Print current state at checkpoint
    pthread_mutex_lock(&printMutex);
    printGrid();
    printAdventurers();
    pthread_mutex_unlock(&printMutex);
}

// Spawn a new adventurer
void spawnNewAdventurer(int x, int y) {
    pthread_mutex_lock(&adventurersMutex);
    
    // Generate random starting position (near the resurrection stone)
    std::uniform_int_distribution<> offsetDist(-2, 2);
    int newX = x + offsetDist(gen);
    int newY = y + offsetDist(gen);
    
    // Ensure position is within bounds
    newX = std::max(0, std::min(newX, gridSize - 1));
    newY = std::max(0, std::min(newY, gridSize - 1));
    
    // Create new adventurer
    int newID = adventurers.size();
    adventurers.emplace_back(newID, newX, newY);
    adventurers.back().markVisited(newX, newY);
    activeAdventurers++;
    
    pthread_mutex_unlock(&adventurersMutex);
    
    pthread_mutex_lock(&printMutex);
    std::cout << "New adventurer " << newID << " spawned at (" << newX << ", " << newY << ")." << std::endl;
    pthread_mutex_unlock(&printMutex);
    
    // Create a new thread for this adventurer
    pthread_t newThread;
    int* arg = new int(newID);  // Allocate memory for the thread argument
    pthread_create(&newThread, NULL, adventurerThread, arg);
    pthread_detach(newThread);  // Detach the thread so we don't need to join it
}

// Check if the game is over
void checkGameOver() {
    pthread_mutex_lock(&adventurersMutex);
    
    // Game is over if all treasures are collected or no adventurers are active
    if (treasuresRemaining <= 0 || activeAdventurers <= 0) {
        gameOver = true;
        
        pthread_mutex_lock(&printMutex);
        std::cout << "Game over condition reached!" << std::endl;
        if (treasuresRemaining <= 0) {
            std::cout << "All treasures have been collected." << std::endl;
        }
        if (activeAdventurers <= 0) {
            std::cout << "All adventurers have been terminated." << std::endl;
        }
        pthread_mutex_unlock(&printMutex);
        
        // Notify all threads to exit
        pthread_mutex_lock(&barrierMutex);
        pthread_cond_broadcast(&barrierCV);
        pthread_mutex_unlock(&barrierMutex);
    }
    
    pthread_mutex_unlock(&adventurersMutex);
}