#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <random>
#include <pthread.h>
#include <omp.h>
#include <atomic>
#include <unistd.h>
#include <algorithm>
#include <ctime>

class GridAdventureGame {
private:
    // Game configuration
    const int GRID_SIZE = 20;
    const int CELL_SIZE = 40;
    const int WINDOW_WIDTH = GRID_SIZE * CELL_SIZE;
    const int WINDOW_HEIGHT = GRID_SIZE * CELL_SIZE + 100;
    const int NUM_THREADS = 5;
    const int CHECKPOINT_INTERVAL = 5;

    // SFML Resources
    sf::RenderWindow window;
    sf::Font font;

    // Grid and Cell representation
    struct Cell {
        enum Type { EMPTY, TREASURE, TRAP, DEADLY_TRAP, RESURRECTION_STONE, BARRIER };
        Type type;
        int value;
        bool visited;
        sf::RectangleShape shape;
        sf::Color baseColor;

        Cell() : type(EMPTY), value(0), visited(false) {}
    };

    struct Adventurer {
        int id;
        sf::CircleShape shape;
        int x, y;
        int score;
        bool active;
        std::vector<std::pair<int, int>> visitedCells;

        Adventurer(int _id, int _x, int _y) : 
            id(_id), 
            x(_x), 
            y(_y), 
            score(0), 
            active(true) 
        {
            shape.setRadius(15);
            shape.setFillColor(sf::Color(rand() % 200, rand() % 200, rand() % 200));
            shape.setOrigin(15, 15);
            visitedCells.push_back(std::make_pair(_x, _y));
        }

        bool hasVisited(int _x, int _y) {
            return std::find(visitedCells.begin(), visitedCells.end(), 
                             std::make_pair(_x, _y)) != visitedCells.end();
        }

        void markVisited(int _x, int _y) {
            visitedCells.push_back(std::make_pair(_x, _y));
        }
    };

    // Global game state
    std::vector<std::vector<Cell>> grid;
    std::vector<Adventurer> adventurers;
    
    // Synchronization primitives
    pthread_mutex_t gridMutex;
    pthread_mutex_t adventurersMutex;
    pthread_mutex_t printMutex;
    pthread_mutex_t barrierMutex;
    pthread_cond_t barrierCV;

    // Game state variables
    std::atomic<bool> gameOver{false};
    int treasuresRemaining{0};
    std::atomic<int> activeAdventurers{0};
    std::atomic<int> moveCounter{0};
    int highestScore = 0;
    int winnerID = -1;
    int barrierCount = 0;
    int barrierThreshold;

    // Random number generator
    std::random_device rd;
    std::mt19937 gen;

    void initializeGrid() {
        grid.resize(GRID_SIZE, std::vector<Cell>(GRID_SIZE));
        treasuresRemaining = 0;
        
        // Use OpenMP to parallelize grid initialization
        #pragma omp parallel
        {
            int localTreasures = 0;
            
            std::random_device localRd;
            std::mt19937 localGen(localRd());
            std::uniform_int_distribution<> typeDist(0, 100);
            std::uniform_int_distribution<> treasureValueDist(10, 50);
            std::uniform_int_distribution<> trapValueDist(5, 25);
            
            #pragma omp for collapse(2)
            for (int i = 0; i < GRID_SIZE; ++i) {
                for (int j = 0; j < GRID_SIZE; ++j) {
                    Cell& cell = grid[i][j];
                    cell.shape.setSize(sf::Vector2f(CELL_SIZE - 2, CELL_SIZE - 2));
                    cell.shape.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                    cell.shape.setOutlineThickness(1);
                    cell.shape.setOutlineColor(sf::Color::Black);

                    int type = typeDist(localGen);
                    
                    if (type < 30) {  // 30% chance of treasure
                        cell.type = Cell::TREASURE;
                        cell.value = treasureValueDist(localGen);
                        cell.baseColor = sf::Color::Yellow;
                        localTreasures++;
                    } else if (type < 50) {  // 20% chance of trap
                        cell.type = Cell::TRAP;
                        cell.value = trapValueDist(localGen);
                        cell.baseColor = sf::Color::Red;
                    } else if (type < 55) {  // 5% chance of deadly trap
                        cell.type = Cell::DEADLY_TRAP;
                        cell.value = trapValueDist(localGen) * 2;
                        cell.baseColor = sf::Color(139, 0, 0);  // Dark Red
                    } else if (type < 58) {  // 3% chance of resurrection stone
                        cell.type = Cell::RESURRECTION_STONE;
                        cell.baseColor = sf::Color::Green;
                    } else if (type < 63) {  // 5% chance of barrier
                        cell.type = Cell::BARRIER;
                        cell.value = treasureValueDist(localGen);
                        cell.baseColor = sf::Color(128, 128, 128);  // Gray
                    } else {
                        cell.type = Cell::EMPTY;
                        cell.baseColor = sf::Color(200, 200, 255);  // Light Blue
                    }

                    cell.shape.setFillColor(cell.baseColor);
                }
            }
            
            #pragma omp critical
            {
                treasuresRemaining += localTreasures;
            }
        }

        // Initialize adventurers
        #pragma omp parallel
        {
            std::random_device localRd;
            std::mt19937 localGen(localRd());
            std::uniform_int_distribution<> posDist(0, GRID_SIZE - 1);
            
            #pragma omp for
            for (int i = 0; i < NUM_THREADS; ++i) {
                int x, y;
                
                #pragma omp critical
                {
                    x = posDist(localGen);
                    y = posDist(localGen);
                    
                    pthread_mutex_lock(&adventurersMutex);
                    adventurers.emplace_back(i, x, y);
                    adventurers[i].markVisited(x, y);
                    activeAdventurers++;
                    pthread_mutex_unlock(&adventurersMutex);
                }
            }
        }

        // Set barrier threshold
        barrierThreshold = NUM_THREADS / 2;
    }

    void drawGame() {
        window.clear(sf::Color::White);

        // Draw grid
        pthread_mutex_lock(&gridMutex);
        for (int i = 0; i < GRID_SIZE; ++i) {
            for (int j = 0; j < GRID_SIZE; ++j) {
                window.draw(grid[i][j].shape);
            }
        }
        pthread_mutex_unlock(&gridMutex);

        // Draw adventurers
        pthread_mutex_lock(&adventurersMutex);
        for (const auto& adv : adventurers) {
            if (adv.active) {
                sf::CircleShape adventurerShape = adv.shape;
                adventurerShape.setPosition(
                    adv.y * CELL_SIZE + CELL_SIZE/2, 
                    adv.x * CELL_SIZE + CELL_SIZE/2
                );
                window.draw(adventurerShape);
            }
        }
        pthread_mutex_unlock(&adventurersMutex);

        // Display scores
        sf::Text scoreText;
        scoreText.setFont(font);
        scoreText.setCharacterSize(20);
        scoreText.setFillColor(sf::Color::Black);
        scoreText.setPosition(10, WINDOW_HEIGHT - 50);

        std::string scoreStr = "Adventurers: ";
        pthread_mutex_lock(&adventurersMutex);
        for (const auto& adv : adventurers) {
            if (adv.active) {
                scoreStr += "ID" + std::to_string(adv.id) + ": " + 
                            std::to_string(adv.score) + " | ";
            }
        }
        pthread_mutex_unlock(&adventurersMutex);
        scoreText.setString(scoreStr);
        window.draw(scoreText);

        window.display();
    }

    static void* adventurerThread(void* arg) {
        GridAdventureGame* game = static_cast<GridAdventureGame*>(arg);
        int id = game->findThreadID();

        while (!game->gameOver) {
            // Check if this adventurer is still active
            pthread_mutex_lock(&game->adventurersMutex);
            bool isActive = game->adventurers[id].active;
            pthread_mutex_unlock(&game->adventurersMutex);
            
            if (!isActive) {
                break;
            }

            // Attempt to make a move
            bool madeMoveSuccessfully = game->makeMove(game->adventurers[id]);
            
            // If couldn't make a move, terminate adventurer
            if (!madeMoveSuccessfully) {
                pthread_mutex_lock(&game->adventurersMutex);
                game->adventurers[id].active = false;
                game->activeAdventurers--;
                pthread_mutex_unlock(&game->adventurersMutex);
                break;
            }

            // Synchronize at checkpoints
            pthread_mutex_lock(&game->adventurersMutex);
            game->moveCounter++;
            bool shouldSync = (game->moveCounter % game->CHECKPOINT_INTERVAL == 0);
            pthread_mutex_unlock(&game->adventurersMutex);
            
            if (shouldSync) {
                game->synchronizeAtCheckpoint();
            }

            // Check game over condition
            game->checkGameOver();

            // Small delay to make moves visible
            usleep(100000);
        }

        return NULL;
    }

    bool makeMove(Adventurer& adv) {
        std::uniform_int_distribution<> dirDist(0, 3);
        std::vector<int> directions = {0, 1, 2, 3};
        std::shuffle(directions.begin(), directions.end(), gen);

        for (int dir : directions) {
            int newX = adv.x;
            int newY = adv.y;

            switch (dir) {
                case 0: newX--; break;  // Up
                case 1: newY++; break;  // Right
                case 2: newX++; break;  // Down
                case 3: newY--; break;  // Left
            }

            // Boundary check
            if (newX < 0 || newX >= GRID_SIZE || newY < 0 || newY >= GRID_SIZE) {
                continue;
            }

            // Check if cell already visited
            pthread_mutex_lock(&adventurersMutex);
            bool hasVisited = adv.hasVisited(newX, newY);
            pthread_mutex_unlock(&adventurersMutex);

            if (hasVisited) {
                continue;
            }

            // Lock grid and adventurer for modification
            pthread_mutex_lock(&gridMutex);
            pthread_mutex_lock(&adventurersMutex);

            Cell& cell = grid[newX][newY];

            // Barrier handling
            if (cell.type == Cell::BARRIER && adv.score < cell.value) {
                pthread_mutex_unlock(&adventurersMutex);
                pthread_mutex_unlock(&gridMutex);
                continue;
            }

            // Update adventurer position
            adv.x = newX;
            adv.y = newY;
            adv.markVisited(newX, newY);
            cell.visited = true;

            // Process cell effects
            int scoreChange = 0;
            bool spawnNewAdventurer = false;
            bool terminateAdventurer = false;

            switch (cell.type) {
                case Cell::TREASURE:
                    adv.score += cell.value;
                    scoreChange = cell.value;
                    treasuresRemaining--;
                    cell.type = Cell::EMPTY;
                    cell.shape.setFillColor(sf::Color(200, 200, 255));
                    break;
                case Cell::TRAP:
                    adv.score -= cell.value;
                    scoreChange = -cell.value;
                    break;
                case Cell::DEADLY_TRAP:
                    adv.score -= cell.value;
                    scoreChange = -cell.value;
                    adv.active = false;
                    activeAdventurers--;
                    terminateAdventurer = true;
                    break;
                case Cell::RESURRECTION_STONE:
                    spawnNewAdventurer = true;
                    cell.type = Cell::EMPTY;
                    cell.shape.setFillColor(sf::Color(200, 200, 255));
                    break;
                default:
                    break;
            }

            // Update highest score
            if (adv.score > highestScore) {
                highestScore = adv.score;
                winnerID = adv.id;
            }

            int advID = adv.id;
            int advScore = adv.score;

            pthread_mutex_unlock(&adventurersMutex);
            pthread_mutex_unlock(&gridMutex);

            // Spawn new adventurer if resurrection stone found
            if (spawnNewAdventurer) {
                spawnAdventurer(newX, newY);
            }

            // Return false if adventurer was terminated
            if (terminateAdventurer) {
                return false;
            }

            return true;
        }

        return false;
    }

    void spawnAdventurer(int x, int y) {
        pthread_mutex_lock(&adventurersMutex);
        
        std::uniform_int_distribution<> offsetDist(-2, 2);
        int newX = x + offsetDist(gen);
        int newY = y + offsetDist(gen);
        
        // Ensure position is within bounds
        newX = std::max(0, std::min(newX, GRID_SIZE - 1));
        newY = std::max(0, std::min(newY, GRID_SIZE - 1));
        
        // Create new adventurer
        int newID = adventurers.size();
        adventurers.emplace_back(newID, newX, newY);
        adventurers.back().markVisited(newX, newY);
        activeAdventurers++;
        
        pthread_mutex_unlock(&adventurersMutex);
    }

    void synchronizeAtCheckpoint() {
        pthread_mutex_lock(&barrierMutex);
        
        barrierCount++;
        
        // If enough adventurers have reached the barrier, release all
        if (barrierCount >= barrierThreshold) {
            barrierCount = 0;
            pthread_cond_broadcast(&barrierCV);
        } else {
            // Wait for more adventurers to reach the barrier
            pthread_cond_wait(&barrierCV, &barrierMutex);
        }
        
        pthread_mutex_unlock(&barrierMutex);
    }

    void checkGameOver() {
        pthread_mutex_lock(&adventurersMutex);
        
        // Game is over if all treasures are collected or no adventurers are active
        if (treasuresRemaining <= 0 || activeAdventurers <= 0) {
            gameOver = true;
        }
        
        pthread_mutex_unlock(&adventurersMutex);
    }

    int findThreadID() {
        pthread_t self = pthread_self();
        pthread_mutex_lock(&adventurersMutex);
        for (size_t i = 0; i < adventurers.size(); ++i) {
            if (adventurers[i].active) {
                pthread_mutex_unlock(&adventurersMutex);
                return i;
            }
        }
        pthread_mutex_unlock(&adventurersMutex);
        return -1;
    }

public:
    GridAdventureGame() : 
        window(sf::VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Grid Adventure Game"),
        gen(rd()) 
    {
        // Initialize mutexes and condition variables
        pthread_mutex_init(&gridMutex, NULL);
        pthread_mutex_init(&adventurersMutex, NULL);
        pthread_mutex_init(&printMutex, NULL);
        pthread_mutex_init(&barrierMutex, NULL);
        pthread_cond_init(&barrierCV, NULL);

        if (!font.loadFromFile("arial.ttf")) {
            std::cerr << "Error loading font" << std::endl;
        }
        
        window.setFramerateLimit(5);
        initializeGrid();
    }

    void run() {
        // Create threads for adventurers
        pthread_t threads[NUM_THREADS];
        
        for (int i = 0; i < NUM_THREADS; ++i) {
            pthread_create(&threads[i], NULL, adventurerThread, this);
        }

        // Main rendering loop
        while (window.isOpen() && !gameOver) {
            sf::Event event;
            while (window.pollEvent(event)) {
                if (event.type == sf::Event::Closed)
                    window.close();
            }

            drawGame();

            // Optional: add a small delay
            sf::sleep(sf::milliseconds(200));

            // Check game over condition
            if (gameOver) break;
        }

        // Wait for all threads to finish
        for (int i = 0; i < NUM_THREADS; ++i) {
            pthread_join(threads[i], NULL);
        }

        // Display final results
        std::cout << "Game Over!" << std::endl;
        std::cout << "Highest Score: " << highestScore << std::endl;
        std::cout << "Winner ID: " << winnerID << std::endl;
        std::cout << "Treasures Remaining: " << treasuresRemaining << std::endl;
        std::cout << "Active Adventurers: " << activeAdventurers << std::endl;

        // Cleanup mutexes
        pthread_mutex_destroy(&gridMutex);
        pthread_mutex_destroy(&adventurersMutex);
        pthread_mutex_destroy(&printMutex);
        pthread_mutex_destroy(&barrierMutex);
        pthread_cond_destroy(&barrierCV);
    }

    ~GridAdventureGame() {}
};

int main() {
    srand(time(nullptr));
    GridAdventureGame game;
    game.run();
    return 0;
}

// Compilation command
// g++ -std=c++11 adventure_game.cpp -o adventure_game -lsfml-graphics -lsfml-window -lsfml-system -pthread -fopenmp