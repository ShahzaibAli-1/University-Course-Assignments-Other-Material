#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <omp.h>

using namespace std;

const int GRID_SIZE = 100;
const int CELL_SIZE = 8;
const int WINDOW_SIZE = GRID_SIZE * CELL_SIZE;
const int GENERATIONS = 500;
const int FPS = 30;

void initialize_grid(vector<vector<char>>& grid) {
    for (int i = 45; i < 55; i++) {
        for (int j = 45; j < 55; j++) {
            grid[i][j] = '*';
        }
    }
}

int count_live_neighbors(const vector<vector<char>>& grid, int x, int y) {
    int count = 0;
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;
            int nx = (x + i + GRID_SIZE) % GRID_SIZE;
            int ny = (y + j + GRID_SIZE) % GRID_SIZE;
            if (grid[nx][ny] == '*') count++;
        }
    }
    return count;
}

void update_grid(vector<vector<char>>& grid) {
    vector<vector<char>> new_grid = grid;
    #pragma omp parallel for collapse(2)
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            int live_neighbors = count_live_neighbors(grid, i, j);
            if (grid[i][j] == '*' && (live_neighbors < 2 || live_neighbors > 3)) {
                new_grid[i][j] = '.';
            } else if (grid[i][j] == '.' && live_neighbors == 3) {
                new_grid[i][j] = '*';
            }
        }
    }
    grid = new_grid;
}

int main() {
    vector<vector<char>> grid(GRID_SIZE, vector<char>(GRID_SIZE, '.'));
    initialize_grid(grid);
    
    sf::RenderWindow window(sf::VideoMode(WINDOW_SIZE, WINDOW_SIZE), "Conway's Game of Life");
    window.setFramerateLimit(FPS);
    
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }
        update_grid(grid);
        
        window.clear(sf::Color::Black);
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                sf::RectangleShape cell(sf::Vector2f(CELL_SIZE - 1, CELL_SIZE - 1));
                cell.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                if (grid[i][j] == '*') {
                    cell.setFillColor(sf::Color::Green);
                } else {
                    cell.setFillColor(sf::Color::Black);
                }
                window.draw(cell);
            }
        }
        window.display();
    }
    return 0;
}


// run krne ka tareeqa 
// g++ -o question_3 Question_3_amar.cpp -lsfml-graphics -lsfml-window -lsfml-system -fopenmp