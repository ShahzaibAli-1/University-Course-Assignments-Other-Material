#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <string.h>

#define GRID_SIZE 100
#define CENTER_SIZE 10
#define GENERATIONS 100
#define NUM_THREADS 4
#define NUM_MEASUREMENTS 5

// Function prototypes
void initializeGrid(char grid[GRID_SIZE][GRID_SIZE]);
void displayGrid(char grid[GRID_SIZE][GRID_SIZE]);
void simulateSerial(char grid[GRID_SIZE][GRID_SIZE], int generations);
void simulateParallelStatic(char grid[GRID_SIZE][GRID_SIZE], int generations);
void simulateParallelGuided(char grid[GRID_SIZE][GRID_SIZE], int generations);
void simulateParallelStaticNoCritical(char grid[GRID_SIZE][GRID_SIZE], int generations);
void simulateParallelGuidedNoCritical(char grid[GRID_SIZE][GRID_SIZE], int generations);
int countNeighbors(char grid[GRID_SIZE][GRID_SIZE], int row, int col);
double measureTime(void (*simulateFunction)(char grid[GRID_SIZE][GRID_SIZE], int), int runs);

int main() {
    // Initialize grid for each measurement
    char grid[GRID_SIZE][GRID_SIZE];
    
    printf("Conway's Game of Life - Performance Analysis\n");
    printf("Grid size: %dx%d, Generations: %d\n\n", GRID_SIZE, GRID_SIZE, GENERATIONS);
    
    // Set number of threads for OpenMP
    omp_set_num_threads(NUM_THREADS);
    printf("Number of OpenMP threads: %d\n\n", NUM_THREADS);
    
    // Measure serial execution time
    double serialTime = measureTime(simulateSerial, NUM_MEASUREMENTS);
    printf("Average Serial Execution Time: %.4f seconds\n", serialTime);
    
    // Measure parallel execution time with static scheduling
    double staticTime = measureTime(simulateParallelStatic, NUM_MEASUREMENTS);
    printf("Average Parallel (Static) Execution Time: %.4f seconds\n", staticTime);
    
    // Measure parallel execution time with guided scheduling
    double guidedTime = measureTime(simulateParallelGuided, NUM_MEASUREMENTS);
    printf("Average Parallel (Guided) Execution Time: %.4f seconds\n", guidedTime);
    
    // Calculate speedups
    printf("\nSpeedup Analysis:\n");
    printf("Static Scheduling Speedup: %.2fx\n", serialTime / staticTime);
    printf("Guided Scheduling Speedup: %.2fx\n", serialTime / guidedTime);
    
    // Compare static vs guided
    printf("\nStatic vs Guided Comparison:\n");
    if (staticTime < guidedTime) {
        printf("Static scheduling is faster by %.2f%%\n", 
               (guidedTime - staticTime) / guidedTime * 100);
    } else {
        printf("Guided scheduling is faster by %.2f%%\n", 
               (staticTime - guidedTime) / staticTime * 100);
    }
    
    // Initialize grid for test run without critical section
    printf("\nTesting without critical section:\n");
    
    // Test run with static scheduling but no critical section
    initializeGrid(grid);
    simulateParallelStaticNoCritical(grid, GENERATIONS);
    printf("Final grid state with static scheduling (no critical section):\n");
    displayGrid(grid);
    
    // Test run with guided scheduling but no critical section
    initializeGrid(grid);
    simulateParallelGuidedNoCritical(grid, GENERATIONS);
    printf("Final grid state with guided scheduling (no critical section):\n");
    displayGrid(grid);
    
    return 0;
}

// Initialize the grid with center 10x10 area as live cells
void initializeGrid(char grid[GRID_SIZE][GRID_SIZE]) {
    // Initialize all cells as dead
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            grid[i][j] = '.';
        }
    }
    
    // Set center 10x10 area to live cells
    int centerStart = (GRID_SIZE - CENTER_SIZE) / 2;
    for (int i = 0; i < CENTER_SIZE; i++) {
        for (int j = 0; j < CENTER_SIZE; j++) {
            grid[centerStart + i][centerStart + j] = '*';
        }
    }
}

// Display the grid
void displayGrid(char grid[GRID_SIZE][GRID_SIZE]) {
    // Count live cells
    int liveCells = 0;
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            if (grid[i][j] == '*') liveCells++;
        }
    }
    
    // Display grid summary (showing full grid would be too large)
    printf("Grid has %d live cells\n", liveCells);
    
    // Display a portion of the grid (center area)
    int displaySize = 20; // Show a 20x20 section around the center
    int centerStart = (GRID_SIZE - displaySize) / 2;
    
    printf("Displaying center %dx%d section:\n", displaySize, displaySize);
    for (int i = 0; i < displaySize; i++) {
        for (int j = 0; j < displaySize; j++) {
            printf("%c", grid[centerStart + i][centerStart + j]);
        }
        printf("\n");
    }
    printf("\n");
}

// Count live neighbors for a cell with toroidal boundary conditions
int countNeighbors(char grid[GRID_SIZE][GRID_SIZE], int row, int col) {
    int count = 0;
    
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue; // Skip the cell itself
            
            // Apply toroidal boundary conditions
            int newRow = (row + i + GRID_SIZE) % GRID_SIZE;
            int newCol = (col + j + GRID_SIZE) % GRID_SIZE;
            
            if (grid[newRow][newCol] == '*') {
                count++;
            }
        }
    }
    
    return count;
}

// Serial implementation of Conway's Game of Life
// Serial implementation of Conway's Game of Life
void simulateSerial(char grid[GRID_SIZE][GRID_SIZE], int generations) {
    char newGrid[GRID_SIZE][GRID_SIZE];
    
    for (int gen = 0; gen < generations; gen++) {
        // Update grid based on Game of Life rules
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int neighbors = countNeighbors(grid, i, j);
                
                if (grid[i][j] == '*') {
                    // Live cell
                    if (neighbors < 2 || neighbors > 3) {
                        // Underpopulation or overpopulation
                        newGrid[i][j] = '.';
                    } else {
                        // Survival
                        newGrid[i][j] = '*';
                    }
                } else {
                    // Dead cell
                    if (neighbors == 3) {
                        // Reproduction
                        newGrid[i][j] = '*';
                    } else {
                        // Remains dead
                        newGrid[i][j] = '.';
                    }
                }
            }
        }
        
        // Copy new grid to current grid
        memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
        
        // Display grid after each generation
        printf("Generation %d:\n", gen + 1);
        displayGrid(grid);
    }
}



// Parallel implementation with static scheduling
void simulateParallelStatic(char grid[GRID_SIZE][GRID_SIZE], int generations) {
    char newGrid[GRID_SIZE][GRID_SIZE];
    
    for (int gen = 0; gen < generations; gen++) {
        // Parallelize row updates with static scheduling
        #pragma omp parallel for schedule(static, 1)
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int neighbors = countNeighbors(grid, i, j);
                
                if (grid[i][j] == '*') {
                    // Live cell
                    if (neighbors < 2 || neighbors > 3) {
                        // Underpopulation or overpopulation
                        newGrid[i][j] = '.';
                    } else {
                        // Survival
                        newGrid[i][j] = '*';
                    }
                } else {
                    // Dead cell
                    if (neighbors == 3) {
                        // Reproduction
                        newGrid[i][j] = '*';
                    } else {
                        // Remains dead
                        newGrid[i][j] = '.';
                    }
                }
            }
        }
        
        // Critical section to update the grid
        #pragma omp critical
        {
            memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
        }
    }
}

// Parallel implementation with guided scheduling
void simulateParallelGuided(char grid[GRID_SIZE][GRID_SIZE], int generations) {
    char newGrid[GRID_SIZE][GRID_SIZE];
    
    for (int gen = 0; gen < generations; gen++) {
        // Parallelize row updates with guided scheduling
        #pragma omp parallel for schedule(guided, 1)
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int neighbors = countNeighbors(grid, i, j);
                
                if (grid[i][j] == '*') {
                    // Live cell
                    if (neighbors < 2 || neighbors > 3) {
                        // Underpopulation or overpopulation
                        newGrid[i][j] = '.';
                    } else {
                        // Survival
                        newGrid[i][j] = '*';
                    }
                } else {
                    // Dead cell
                    if (neighbors == 3) {
                        // Reproduction
                        newGrid[i][j] = '*';
                    } else {
                        // Remains dead
                        newGrid[i][j] = '.';
                    }
                }
            }
        }
        
        // Critical section to update the grid
        #pragma omp critical
        {
            memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
        }
    }
}

// Parallel implementation with static scheduling (no critical section)
void simulateParallelStaticNoCritical(char grid[GRID_SIZE][GRID_SIZE], int generations) {
    char newGrid[GRID_SIZE][GRID_SIZE];
    
    for (int gen = 0; gen < generations; gen++) {
        // Parallelize row updates with static scheduling
        #pragma omp parallel for schedule(static, 1)
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int neighbors = countNeighbors(grid, i, j);
                
                if (grid[i][j] == '*') {
                    // Live cell
                    if (neighbors < 2 || neighbors > 3) {
                        // Underpopulation or overpopulation
                        newGrid[i][j] = '.';
                    } else {
                        // Survival
                        newGrid[i][j] = '*';
                    }
                } else {
                    // Dead cell
                    if (neighbors == 3) {
                        // Reproduction
                        newGrid[i][j] = '*';
                    } else {
                        // Remains dead
                        newGrid[i][j] = '.';
                    }
                }
            }
        }
        
        // No critical section - directly copy the grid
        memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
    }
}

// Parallel implementation with guided scheduling (no critical section)
void simulateParallelGuidedNoCritical(char grid[GRID_SIZE][GRID_SIZE], int generations) {
    char newGrid[GRID_SIZE][GRID_SIZE];
    
    for (int gen = 0; gen < generations; gen++) {
        // Parallelize row updates with guided scheduling
        #pragma omp parallel for schedule(guided, 1)
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                int neighbors = countNeighbors(grid, i, j);
                
                if (grid[i][j] == '*') {
                    // Live cell
                    if (neighbors < 2 || neighbors > 3) {
                        // Underpopulation or overpopulation
                        newGrid[i][j] = '.';
                    } else {
                        // Survival
                        newGrid[i][j] = '*';
                    }
                } else {
                    // Dead cell
                    if (neighbors == 3) {
                        // Reproduction
                        newGrid[i][j] = '*';
                    } else {
                        // Remains dead
                        newGrid[i][j] = '.';
                    }
                }
            }
        }
        
        // No critical section - directly copy the grid
        memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
    }
}

// Function to measure average execution time
double measureTime(void (*simulateFunction)(char grid[GRID_SIZE][GRID_SIZE], int), int runs) {
    double totalTime = 0.0;
    char grid[GRID_SIZE][GRID_SIZE];
    
    for (int run = 0; run < runs; run++) {
        // Initialize grid for this run
        initializeGrid(grid);
        
        // Start timer
        double startTime = omp_get_wtime();
        
        // Run simulation
        simulateFunction(grid, GENERATIONS);
        
        // End timer
        double endTime = omp_get_wtime();
        
        // Add to total time
        totalTime += (endTime - startTime);
        
        // Display final grid on the last run
        if (run == runs - 1) {
            printf("Final grid state after simulation:\n");
            displayGrid(grid);
        }
    }
    
    // Return average time
    return totalTime / runs;
}