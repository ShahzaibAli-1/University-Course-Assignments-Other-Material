#include <iostream>
#include <vector>
#include <omp.h>

using namespace std;

const int KERNEL_SIZE = 3;
const int OFFSET = KERNEL_SIZE / 2;

void box_blur_serial(const vector<vector<int>>& input, vector<vector<int>>& output, int N, int M) {
    for (int i = 1; i < N - 1; i++) {
        for (int j = 1; j < M - 1; j++) {
            int sum = 0;
            for (int ki = -1; ki <= 1; ki++) {
                for (int kj = -1; kj <= 1; kj++) {
                    sum += input[i + ki][j + kj];
                }
            }
            output[i][j] = sum / 9;
        }
    }
}

void box_blur_parallel(const vector<vector<int>>& input, vector<vector<int>>& output, int N, int M, int num_threads) {
    #pragma omp parallel for num_threads(num_threads) collapse(2)
    for (int i = 1; i < N - 1; i++) {
        for (int j = 1; j < M - 1; j++) {
            int sum = 0;
            for (int ki = -1; ki <= 1; ki++) {
                for (int kj = -1; kj <= 1; kj++) {
                    sum += input[i + ki][j + kj];
                }
            }
            output[i][j] = sum / 9;
        }
    }
}

int main() {
    vector<int> sizes = {1000, 2000, 3000, 5000};
    vector<int> threads = {1, 2, 4, 8, 12, 16};
    
    for (int size : sizes) {
        int N = size, M = size;
        vector<vector<int>> input(N, vector<int>(M, 128)); // Initialize with some value
        vector<vector<int>> output(N, vector<int>(M, 0));
        
        cout << "Image Size: " << N << "x" << M << "\n";
        
        // Sequential execution
        double start = omp_get_wtime();
        box_blur_serial(input, output, N, M);
        double end = omp_get_wtime();
        cout << "Serial Execution Time: " << (end - start) << " seconds\n";
        
        // Parallel execution
        for (int t : threads) {
            double start_p = omp_get_wtime();
            box_blur_parallel(input, output, N, M, t);
            double end_p = omp_get_wtime();
            cout << t << " Threads Execution Time: " << (end_p - start_p) << " seconds\n";
        }
        cout << "\n";
    }
    return 0;
}
