#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <string.h>
#include <SFML/Graphics.hpp>

#define GRID_SIZE 100
#define CENTER_SIZE 10
#define GENERATIONS 1000
#define NUM_THREADS 4
#define CELL_SIZE 8  // Size of each cell in pixels

// Function prototypes
void initializeGrid(char grid[GRID_SIZE][GRID_SIZE]);
int countNeighbors(char grid[GRID_SIZE][GRID_SIZE], int row, int col);
void update(char grid[GRID_SIZE][GRID_SIZE], char newGrid[GRID_SIZE][GRID_SIZE]);
void randomizeGrid(char grid[GRID_SIZE][GRID_SIZE], float density);

// Color configurations
sf::Color BACKGROUND_COLOR(10, 10, 15);
sf::Color ALIVE_COLOR(50, 200, 100);
sf::Color DYING_COLOR(200, 60, 60);
sf::Color BIRTH_COLOR(100, 100, 255);
sf::Color GRID_COLOR(30, 30, 40);

int main() {
    // Initialize random seed
    srand(time(NULL));
    
    // Create window
    sf::RenderWindow window(sf::VideoMode(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE), 
                           "Conway's Game of Life - SFML Visualization");
    window.setFramerateLimit(30);  // Limit to 30 FPS
    
    // Set number of threads for OpenMP
    omp_set_num_threads(NUM_THREADS);
    printf("Number of OpenMP threads: %d\n", NUM_THREADS);
    
    // Initialize game grid
    char grid[GRID_SIZE][GRID_SIZE];
    char newGrid[GRID_SIZE][GRID_SIZE];
    char prevGrid[GRID_SIZE][GRID_SIZE]; // To track changes for coloring
    
    initializeGrid(grid);
    memcpy(prevGrid, grid, GRID_SIZE * GRID_SIZE * sizeof(char));
    
    // Create cell shape for drawing
    sf::RectangleShape cellShape(sf::Vector2f(CELL_SIZE-1, CELL_SIZE-1));
    
    // Create font and text for UI
    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        printf("Error loading font. Using default visualization without text.\n");
    }
    
    sf::Text generationText;
    generationText.setFont(font);
    generationText.setCharacterSize(16);
    generationText.setFillColor(sf::Color::White);
    generationText.setPosition(10, 10);
    
    sf::Text instructionsText;
    instructionsText.setFont(font);
    instructionsText.setCharacterSize(14);
    instructionsText.setFillColor(sf::Color::White);
    instructionsText.setPosition(10, GRID_SIZE * CELL_SIZE - 80);
    instructionsText.setString("Space: Pause/Resume\nR: Randomize\nC: Clear\nS: Step (when paused)");
    
    // Main simulation variables
    int generation = 0;
    bool paused = false;
    bool step = false;
    
    // Main loop
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            
            // Handle keyboard input
            if (event.type == sf::Event::KeyPressed) {
                switch (event.key.code) {
                    case sf::Keyboard::Escape:
                        window.close();
                        break;
                    case sf::Keyboard::Space:
                        paused = !paused;
                        break;
                    case sf::Keyboard::R:
                        randomizeGrid(grid, 0.3f); // 30% density
                        memcpy(prevGrid, grid, GRID_SIZE * GRID_SIZE * sizeof(char));
                        break;
                    case sf::Keyboard::C:
                        // Clear grid
                        for (int i = 0; i < GRID_SIZE; i++)
                            for (int j = 0; j < GRID_SIZE; j++)
                                grid[i][j] = '.';
                        memcpy(prevGrid, grid, GRID_SIZE * GRID_SIZE * sizeof(char));
                        break;
                    case sf::Keyboard::S:
                        if (paused) step = true;
                        break;
                }
            }
            
            // Handle mouse clicks to toggle cells
            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    int x = event.mouseButton.x / CELL_SIZE;
                    int y = event.mouseButton.y / CELL_SIZE;
                    
                    if (x >= 0 && x < GRID_SIZE && y >= 0 && y < GRID_SIZE) {
                        // Toggle cell state
                        grid[y][x] = (grid[y][x] == '*') ? '.' : '*';
                        prevGrid[y][x] = grid[y][x]; // Update prevGrid to match
                    }
                }
            }
        }
        
        // Update simulation if not paused or stepping
        if (!paused || step) {
            // Save current state to prevGrid for change detection
            memcpy(prevGrid, grid, GRID_SIZE * GRID_SIZE * sizeof(char));
            
            // Update grid with parallel processing
            #pragma omp parallel for schedule(guided, 1)
            for (int i = 0; i < GRID_SIZE; i++) {
                for (int j = 0; j < GRID_SIZE; j++) {
                    int neighbors = countNeighbors(grid, i, j);
                    
                    if (grid[i][j] == '*') {
                        // Live cell
                        if (neighbors < 2 || neighbors > 3) {
                            // Underpopulation or overpopulation
                            newGrid[i][j] = '.';
                        } else {
                            // Survival
                            newGrid[i][j] = '*';
                        }
                    } else {
                        // Dead cell
                        if (neighbors == 3) {
                            // Reproduction
                            newGrid[i][j] = '*';
                        } else {
                            // Remains dead
                            newGrid[i][j] = '.';
                        }
                    }
                }
            }
            
            // Copy new grid to current grid
            memcpy(grid, newGrid, GRID_SIZE * GRID_SIZE * sizeof(char));
            
            generation++;
            step = false; // Reset step flag
            
            // Update generation text
            generationText.setString("Generation: " + std::to_string(generation));
        }
        
        // Clear the window
        window.clear(BACKGROUND_COLOR);
        
        // Draw grid lines
        if (CELL_SIZE >= 5) { // Only draw grid lines if cells are big enough
            for (int i = 0; i <= GRID_SIZE; i++) {
                sf::Vertex horizontalLine[] = {
                    sf::Vertex(sf::Vector2f(0, i * CELL_SIZE), GRID_COLOR),
                    sf::Vertex(sf::Vector2f(GRID_SIZE * CELL_SIZE, i * CELL_SIZE), GRID_COLOR)
                };
                
                sf::Vertex verticalLine[] = {
                    sf::Vertex(sf::Vector2f(i * CELL_SIZE, 0), GRID_COLOR),
                    sf::Vertex(sf::Vector2f(i * CELL_SIZE, GRID_SIZE * CELL_SIZE), GRID_COLOR)
                };
                
                window.draw(horizontalLine, 2, sf::Lines);
                window.draw(verticalLine, 2, sf::Lines);
            }
        }
        
        // Draw cells with color indicators for state changes
        for (int i = 0; i < GRID_SIZE; i++) {
            for (int j = 0; j < GRID_SIZE; j++) {
                if (grid[i][j] == '*') {
                    cellShape.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                    
                    // Color based on state change
                    if (prevGrid[i][j] == '.') {
                        // Just born
                        cellShape.setFillColor(BIRTH_COLOR);
                    } else {
                        // Already alive
                        cellShape.setFillColor(ALIVE_COLOR);
                    }
                    
                    window.draw(cellShape);
                } else if (prevGrid[i][j] == '*') {
                    // Just died
                    cellShape.setPosition(j * CELL_SIZE, i * CELL_SIZE);
                    cellShape.setFillColor(DYING_COLOR);
                    window.draw(cellShape);
                }
            }
        }
        
        // Draw UI text
        window.draw(generationText);
        window.draw(instructionsText);
        
        // Display everything
        window.display();
    }
    
    return 0;
}

// Initialize the grid with center 10x10 area as live cells
void initializeGrid(char grid[GRID_SIZE][GRID_SIZE]) {
    // Initialize all cells as dead
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            grid[i][j] = '.';
        }
    }
    
    // Set center area to live cells
    int centerStart = (GRID_SIZE - CENTER_SIZE) / 2;
    for (int i = 0; i < CENTER_SIZE; i++) {
        for (int j = 0; j < CENTER_SIZE; j++) {
            grid[centerStart + i][centerStart + j] = '*';
        }
    }
}

// Create a random grid with a given density of live cells
void randomizeGrid(char grid[GRID_SIZE][GRID_SIZE], float density) {
    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            float r = (float)rand() / RAND_MAX;
            grid[i][j] = (r < density) ? '*' : '.';
        }
    }
}

// Count live neighbors for a cell with toroidal boundary conditions
int countNeighbors(char grid[GRID_SIZE][GRID_SIZE], int row, int col) {
    int count = 0;
    
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue; // Skip the cell itself
            
            // Apply toroidal boundary conditions
            int newRow = (row + i + GRID_SIZE) % GRID_SIZE;
            int newCol = (col + j + GRID_SIZE) % GRID_SIZE;
            
            if (grid[newRow][newCol] == '*') {
                count++;
            }
        }
    }
    
    return count;
}


// # For Linux/macOS with g++
// g++ -o conway_sfml conway_sfml.cpp -lsfml-graphics -lsfml-window -lsfml-system -fopenmp