#include <iostream>
#include <vector>
#include <omp.h>
#include <pthread.h>
#include <unistd.h>

using namespace std;
const int N = 100; // Grid size
const int generations = 100;

// Function to initialize the grid
void initializeGrid(vector<vector<char>> &grid) {
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            grid[i][j] = '.';
        }
    }
    for (int i = 45; i < 55; ++i) {
        for (int j = 45; j < 55; ++j) {
            grid[i][j] = '*';
        }
    }
}

// Function to count live neighbors with toroidal boundary conditions
int countLiveNeighbors(const vector<vector<char>> &grid, int x, int y) {
    int count = 0;
    for (int i = -1; i <= 1; ++i) {
        for (int j = -1; j <= 1; ++j) {
            if (i == 0 && j == 0) continue;
            int ni = (x + i + N) % N;
            int nj = (y + j + N) % N;
            if (grid[ni][nj] == '*') count++;
        }
    }
    return count;
}

// Function to update the grid and display each step
void updateGridWithDisplay(vector<vector<char>> &grid) {
    for (int gen = 0; gen < generations; ++gen) {
        vector<vector<char>> newGrid = grid;
        #pragma omp parallel for schedule(static, 1)
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                int liveNeighbors = countLiveNeighbors(grid, i, j);
                if (grid[i][j] == '*' && (liveNeighbors < 2 || liveNeighbors > 3)) {
                    newGrid[i][j] = '.';
                } else if (grid[i][j] == '.' && liveNeighbors == 3) {
                    newGrid[i][j] = '*';
                }
            }
        }
        grid = newGrid;
        
        // Display grid visually step by step
        system("clear");
        for (const auto &row : grid) {
            for (char cell : row) {
                cout << cell << " ";
            }
            cout << endl;
        }
        usleep(100000); // Delay for visualization
    }
}

int main() {
    vector<vector<char>> grid(N, vector<char>(N));
    initializeGrid(grid);
    updateGridWithDisplay(grid);
    return 0;
}
