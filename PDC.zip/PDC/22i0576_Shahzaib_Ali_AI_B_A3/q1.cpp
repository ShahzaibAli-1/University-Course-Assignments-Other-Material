#include <iostream>
#include <vector>
#include <cstdlib> // For rand()
#include <ctime>   // For time
#include <omp.h>   // For OpenMP

using namespace std;


void applyBoxBlur(vector<vector<int>>& image, vector<vector<int>>& output, int N, int num_threads) 
{
    #pragma omp parallel for collapse(2) num_threads(num_threads)
    for (int i = 1; i < N - 1; i++) 
    {
        for (int j = 1; j < N - 1; j++) 
        {
            int sum = 0;
            for (int x = -1; x <= 1; x++) 
            {
                for (int y = -1; y <= 1; y++) 
                {
                    sum += image[i + x][j + y];
                }
            }
            output[i][j] = sum / 9;
        }
    }
}

int main() 
{
    vector<int> sizes = {1000, 2000, 3000, 5000};
    vector<int> threads = {1, 2, 4, 8, 12, 16};

    for (int N : sizes) 
    {
        cout << "Image Size: " << N << "x" << N << endl;
        vector<vector<int>> image(N, vector<int>(N));
        vector<vector<int>> output(N, vector<int>(N, 0)); // Output image with zero padding

        srand(time(0)); 

        // Fill the image with random values between 0 and 255
        for (int i = 0; i < N; i++) 
        {
            for (int j = 0; j < N; j++) {
                image[i][j] = rand() % 256;
            }
        }

        for (int num_threads : threads) 
        {
            clock_t start_time = clock(); // Start timing
            applyBoxBlur(image, output, N, num_threads);
            clock_t end_time = clock(); // End timing

            double execution_time = double(end_time - start_time) / CLOCKS_PER_SEC;
            cout << "Threads: " << num_threads << " Execution time: " << execution_time << " seconds" << endl;
        }
        cout << "----------------------------------" << endl;
    }
    return 0;
}
