#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <stdbool.h> 

#define MATRIX_SIZE 1024
#define NUM_THREADS 6
#define TOLERANCE 1e-9 

double matrix[MATRIX_SIZE][MATRIX_SIZE];
double log_matrix[MATRIX_SIZE][MATRIX_SIZE];
double sequential_log_matrix[MATRIX_SIZE][MATRIX_SIZE]; 

typedef struct {
    int thread_id;
} ThreadData;

//function for multi-threaded logarithm transformation
void* compute_logarithm(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    for (int i = data->thread_id; i < MATRIX_SIZE; i += NUM_THREADS) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            log_matrix[i][j] = log(matrix[i][j]);
        }
    }
    pthread_exit(NULL);
}

// Function for sequential logarithm transformation
void sequential_logarithm() {
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            sequential_log_matrix[i][j] = log(matrix[i][j]);
        }
    }
}

// Function for verifying correctness 
bool CorrectOutputCheck() {
    sequential_logarithm();
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            if (fabs(log_matrix[i][j] - sequential_log_matrix[i][j]) > TOLERANCE) {
                return false; 
            }
        }
    }
    return true; 
}

// Function to print a small sample of a matrix
void printMatrixSample(double mat[MATRIX_SIZE][MATRIX_SIZE], int rows, int cols, const char* title) {
    printf("%s (Top-Left %dx%d):\n", title, rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%7.4f ", mat[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    pthread_t threads[NUM_THREADS];
    ThreadData thread_data[NUM_THREADS];

    // Initialize matrix with random values (greater than 0 to avoid log(0))
    for (int i = 0; i < MATRIX_SIZE; i++) {
        for (int j = 0; j < MATRIX_SIZE; j++) {
            matrix[i][j] = (double)rand() / RAND_MAX + 1; // Ensures positive values
        }
    }

    // Print a small portion of the original matrix
    printMatrixSample(matrix, 10, 10, "Original Matrix");

    // Create threads for row-wise cyclic distribution
    for (int i = 0; i < NUM_THREADS; i++) {
        thread_data[i].thread_id = i;
        pthread_create(&threads[i], NULL, compute_logarithm, (void*)&thread_data[i]);
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }

    //Printing a small portion of matrix
    printMatrixSample(log_matrix, 10, 10, "Log-Transformed Matrix");

    //verifying correctness
    if (CorrectOutputCheck()) {
        printf("Logarithm transformation is correct.\n");
    } else {
        printf("Logarithm transformation is incorrect.\n");
    }

    return 0;
}
