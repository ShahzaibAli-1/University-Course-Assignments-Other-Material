#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>
#include <time.h>

// Node structure for linked list
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Thread argument structure for parallel quicksort
typedef struct {
    Node* head;
    Node** sortedHead;
} QuickSortArg;

typedef struct {
    int* numbers;
    int start;
    int end;
    Node** head;
} ThreadArg;

// Function declarations
void readRollNumbers(FILE* inputFile, int* Numbers, int num);
void addRollNumbersToList(Node** head, int* Numbers, int num);
Node* quickSort(Node* head);

void* addRollNumbersToListParallel(void* arg);
void* quickSortParallel(void* arg);
void setAffinity(pthread_t thread, int coreId);

// Helper functions
Node* getTail(Node* head);
Node* partition(Node* head, Node* end, Node** newHead, Node** newEnd);
Node* quickSortRecur(Node* head, Node* end);
void printList(Node* head);

// Serial functions
void readRollNumbers(FILE* inputFile, int* Numbers, int num) {
    for (int i = 0; i < num; i++) {
        if (fscanf(inputFile, "%d", &Numbers[i]) != 1) {
            fprintf(stderr, "Error reading number %d\n", i);
            exit(EXIT_FAILURE);
        }
    }
}

void addRollNumbersToList(Node** head, int* Numbers, int num) {
    for (int i = 0; i < num; i++) {
        Node* newNode = (Node*)malloc(sizeof(Node));
        newNode->data = Numbers[i];
        newNode->next = *head;
        *head = newNode;
    }
}

// QuickSort Helper Functions
Node* getTail(Node* head) {
    while (head != NULL && head->next != NULL) {
        head = head->next;
    }
    return head;
}

Node* partition(Node* head, Node* end, Node** newHead, Node** newEnd) {
    Node* pivot = end;
    Node* prev = NULL, *cur = head, *tail = pivot;

    while (cur != pivot) {
        if (cur->data < pivot->data) {
            if (*newHead == NULL) *newHead = cur;
            prev = cur;
            cur = cur->next;
        } else {
            if (prev) prev->next = cur->next;
            Node* tmp = cur->next;
            cur->next = NULL;
            tail->next = cur;
            tail = cur;
            cur = tmp;
        }
    }

    if (*newHead == NULL) *newHead = pivot;
    *newEnd = tail;
    return pivot;
}

Node* quickSortRecur(Node* head, Node* end) {
    if (!head || head == end) return head;

    Node* newHead = NULL, *newEnd = NULL;
    Node* pivot = partition(head, end, &newHead, &newEnd);

    if (newHead != pivot) {
        Node* tmp = newHead;
        while (tmp->next != pivot) tmp = tmp->next;
        tmp->next = NULL;

        newHead = quickSortRecur(newHead, tmp);
        tmp = getTail(newHead);
        tmp->next = pivot;
    }

    pivot->next = quickSortRecur(pivot->next, newEnd);
    return newHead;
}

Node* quickSort(Node* head) {
    return quickSortRecur(head, getTail(head));
}

// Parallel Functions
void setAffinity(pthread_t thread, int coreId) {
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(coreId, &cpuset);

    int result = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
    if (result != 0) {
        perror("pthread_setaffinity_np");
        exit(EXIT_FAILURE);
    }
}

void* addRollNumbersToListParallel(void* arg) {
    ThreadArg* tArg = (ThreadArg*)arg;
    for (int i = tArg->start; i < tArg->end; i++) {
        Node* newNode = (Node*)malloc(sizeof(Node));
        newNode->data = tArg->numbers[i];

        static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
        pthread_mutex_lock(&lock);
        newNode->next = *(tArg->head);
        *(tArg->head) = newNode;
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

void* quickSortParallel(void* arg) {
    QuickSortArg* qsArg = (QuickSortArg*)arg;
    Node* head = qsArg->head;
    if (!head || !head->next) {
        qsArg->sortedHead = &head;
        return NULL;
    }

    Node* end = getTail(head);
    Node* newHead = NULL, *newEnd = NULL;
    Node* pivot = partition(head, end, &newHead, &newEnd);

    pthread_t leftThread, rightThread;
    QuickSortArg leftArg = {newHead, NULL};
    QuickSortArg rightArg = {pivot->next, NULL};

    if (newHead != pivot) {
        Node* tmp = newHead;
        while (tmp->next != pivot) tmp = tmp->next;
        tmp->next = NULL;

        pthread_create(&leftThread, NULL, quickSortParallel, &leftArg);
        pthread_join(leftThread, NULL);

        tmp = getTail(leftArg.head);
        tmp->next = pivot;
    }

    pthread_create(&rightThread, NULL, quickSortParallel, &rightArg);
    pthread_join(rightThread, NULL);
    
    pivot->next = rightArg.head;
    qsArg->sortedHead = newHead ? &newHead : &pivot;
    return NULL;
}

// Helper function to print the list
void printList(Node* head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->next;
    }
    printf("NULL\n");
}

// Main function
int main() {
    FILE* inputFile = fopen("numbers.txt", "r");
    if (!inputFile) {
        perror("Error opening file");
        return EXIT_FAILURE;
    }

    int num;
    fscanf(inputFile, "%d", &num);
    int* numbers = (int*)malloc(num * sizeof(int));

    readRollNumbers(inputFile, numbers, num);
    fclose(inputFile);

    // Serial portion
    Node* serialHead = NULL;

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    addRollNumbersToList(&serialHead, numbers, num);
    serialHead = quickSort(serialHead);

    clock_gettime(CLOCK_MONOTONIC, &end);
    double serialTime = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("Serial Sorted List:\n");
    printList(serialHead);
    printf("Serial Execution Time: %.6f seconds\n\n", serialTime);

    // Parallel portion
    Node* parallelHead = NULL;
    int numThreads = 4;
    pthread_t threads[numThreads];
    ThreadArg threadArgs[numThreads];

    int chunkSize = num / numThreads;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (int i = 0; i < numThreads; i++) {
        threadArgs[i] = (ThreadArg){numbers, i * chunkSize, (i == numThreads - 1) ? num : (i + 1) * chunkSize, &parallelHead};
        pthread_create(&threads[i], NULL, addRollNumbersToListParallel, &threadArgs[i]);
    }

    for (int i = 0; i < numThreads; i++) {
        pthread_join(threads[i], NULL);
    }

    QuickSortArg qsArg = {parallelHead, NULL};
    pthread_t sortThread;
    pthread_create(&sortThread, NULL, quickSortParallel, &qsArg);
    pthread_join(sortThread, NULL);

    clock_gettime(CLOCK_MONOTONIC, &end);
    double parallelTime = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("Parallel Sorted List:\n");
    printList(*qsArg.sortedHead);
    printf("Parallel Execution Time: %.6f seconds\n", parallelTime);

    free(numbers);
    return 0;
}
