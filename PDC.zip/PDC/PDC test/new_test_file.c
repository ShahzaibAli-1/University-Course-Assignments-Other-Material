#include <stdio.h>
#include <omp.h>  // OpenMP library
const int  SIZE =  100;
int main() {
    // Parallel region: multiple threads will execute this
    int i , sum = 0;
    int arr[SIZE];

    for (int i=  0 ;i<SIZE;i++){
        arr[i] = i+1;
    }
    #pragma omp parallel for reduction(+:sum)
    
        for(int i =0  ;i<SIZE;i++)
        sum+=arr[i];
    
    printf("Sum of array: %d\n", sum);
    return 0;
}
