#include <stdio.h>
#include <omp.h>

int main() {
    int initial_weight = 5;
    int final_weight = 0;

    #pragma omp parallel for firstprivate(initial_weight) lastprivate(final_weight)
    for (int i = 0; i < 4; i++) {
        initial_weight += i; // each thread starts from 5
        final_weight = initial_weight * 2;
        printf("Thread %d: i=%d, weight=%d, final_weight=%d\n", 
               omp_get_thread_num(), i, initial_weight, final_weight);
    }

    printf("Final weight after loop: %d\n", final_weight);
    return 0;
}
