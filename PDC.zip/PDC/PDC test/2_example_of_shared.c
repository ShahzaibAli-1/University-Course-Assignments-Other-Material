#include <stdio.h>
#include <omp.h>

int main() {
    int counter = 0;

    #pragma omp parallel for shared(counter)
    for (int i = 0; i < 10; i++) {
        #pragma omp critical
        {
            counter++;
            printf("Thread %d incremented counter to %d\n", omp_get_thread_num(), counter);
        }
    }

    printf("Final counter value: %d\n", counter);
    return 0;
}
