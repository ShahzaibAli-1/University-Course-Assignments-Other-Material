
#include<omp.h>
#include<stdio.h>

int main(int argc, char *argv[]){
int sum ,c
#pragma omp parallel num_threads(2){
}



}