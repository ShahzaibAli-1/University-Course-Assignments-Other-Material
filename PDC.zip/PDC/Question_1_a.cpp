#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>

#define SIZE 1024
#define THREADS 6
#define TOLERANCE 1e-6 

double matrix[SIZE][SIZE];

// Struct to pass to threads
typedef struct {
    int row_start;
    int row_end;
    int col_start;
    int col_end;
} ThreadData;

// Function to compute 2x2 determinant
double compute_2x2_determinant(double a, double b, double c, double d) {
    return (a * d) - (b * c);
}

// Thread function to compute determinant of a block
void* compute_determinant(void* arg) {
    ThreadData* data = (ThreadData*)arg;
    double determinant = 0.0;

    for (int i = data->row_start; i < data->row_end; i += 2) {
        for (int j = data->col_start; j < data->col_end; j += 2) {
            if (i + 1 < SIZE && j + 1 < SIZE) {
                determinant += compute_2x2_determinant(
                    matrix[i][j], matrix[i][j + 1],
                    matrix[i + 1][j], matrix[i + 1][j + 1]
                );
            }
        }
    }

    double* result = (double*)malloc(sizeof(double));
    *result = determinant;
    pthread_exit(result);
}

// Sequential computation of determinant approximation
double sequential_determinant() {
    double determinant = 0.0;

    for (int i = 0; i < SIZE; i += 2) {
        for (int j = 0; j < SIZE; j += 2) {
            if (i + 1 < SIZE && j + 1 < SIZE) {
                determinant += compute_2x2_determinant(
                    matrix[i][j], matrix[i][j + 1],
                    matrix[i + 1][j], matrix[i + 1][j + 1]
                );
            }
        }
    }
    return determinant;
}

// Function to check correctness
int CorrectOutputCheck(double multi_threaded_result) {
    double sequential_result = sequential_determinant();
    return (fabs(multi_threaded_result - sequential_result) < TOLERANCE);
}

// Function to print a small portion of the matrix
void printMatrixSample(int rows, int cols) {
    printf("Matrix Sample (Top-Left %dx%d):\n", rows, cols);
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%2.0f ", matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    pthread_t threads[THREADS];
    ThreadData thread_data[THREADS];

    // Initialize matrix with random values (1 to 10)
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            matrix[i][j] = rand() % 10 + 1;
        }
    }

    // Print a small portion of the matrix
    printMatrixSample(10, 10);

    // Divide work among threads
    int block_size = SIZE / 3; 
    int thread_index = 0;

    for (int i = 0; i < SIZE; i += block_size) {
        for (int j = 0; j < SIZE; j += block_size) {
            if (thread_index >= THREADS) break;

            thread_data[thread_index].row_start = i;
            thread_data[thread_index].row_end = i + block_size;
            thread_data[thread_index].col_start = j;
            thread_data[thread_index].col_end = j + block_size;

            pthread_create(&threads[thread_index], NULL, compute_determinant, &thread_data[thread_index]);
            thread_index++;
        }
    }

    // Collect results
    double total_determinant = 0.0;
    for (int i = 0; i < THREADS; i++) {
        double* partial_det;
        pthread_join(threads[i], (void**)&partial_det);
        total_determinant += *partial_det;
        free(partial_det);
    }

    // Correctness check
    if (CorrectOutputCheck(total_determinant)) {
        printf("Multi-threaded determinant is incorrect.\n");
    } else {
        printf("Multi-threaded determinant is correct.\n");
    }

    // Print final result
    printf("Total Determinant (approximate): %f\n", total_determinant);
    return 0;
}
